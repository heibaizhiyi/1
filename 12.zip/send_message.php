<?php
session_start();
if (!isset($_SESSION['customer_logged_in']) && !isset($_SESSION['admin_logged_in'])) {
    exit;
}

include 'db_config.php';

$message_content = trim($_POST['message_content']);
$receiver_id = intval($_POST['receiver_id']);

if (!empty($message_content)) {
    if (isset($_SESSION['customer_logged_in'])) {
        $sender_id = $_SESSION['customer_id'];
        $sender_type = 'customer';
    } else {
        $sender_id = $_SESSION['admin_id'];
        $sender_type = 'admin';
    }

    $insert_sql = 'INSERT INTO chat_messages (sender_id, receiver_id, message, sender_type) VALUES (?, ?, ?, ?)';
    $stmt = mysqli_prepare($conn, $insert_sql);
    mysqli_stmt_bind_param($stmt, 'iiss', $sender_id, $receiver_id, $message_content, $sender_type);
    mysqli_stmt_execute($stmt);
}
?>
