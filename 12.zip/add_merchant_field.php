<?php
include 'db_config.php';
$sql = "ALTER TABLE members ADD COLUMN merchant_username VARCHAR(50) NULL DEFAULT NULL";
if (mysqli_query($conn, $sql)) {
    echo "商家名字段添加成功";
} else {
    echo "添加失败: " . mysqli_error($conn);
}
mysqli_close($conn);
?>