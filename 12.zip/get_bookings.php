<?php
include 'db_config.php';

// 查询所有预约记录
$bookings = mysqli_fetch_all(mysqli_query($conn, "SELECT cpr.id, m.name, m.phone, p.package_name, cpr.book_time, cpr.is_confirmed, cpr.actual_price, cpr.is_paid, cpr.is_completed FROM customer_package_records cpr LEFT JOIN members m ON cpr.customer_id = m.id LEFT JOIN packages p ON cpr.package_id = p.id ORDER BY cpr.create_time DESC"), MYSQLI_ASSOC);
?>
<tr>
    <th>预约ID</th>
    <th>客户姓名</th>
    <th>客户手机号</th>
    <th>套餐名称</th>
    <th>预约时间</th>
    <th>确认状态</th>
    <th>实际价格（元）</th>
    <th>付款状态</th>
    <th>完成状态</th>
    <th>操作</th>
</tr>
<?php if (empty($bookings)): ?>
    <tr>
        <td colspan="10" class="no-data">暂无预约记录</td>
    </tr>
<?php else: ?>
    <?php foreach ($bookings as $booking): ?>
        <tr>
            <td><?php echo $booking['id']; ?></td>
            <td><?php echo $booking['name']; ?></td>
            <td><?php echo $booking['phone']; ?></td>
            <td><?php echo $booking['package_name']; ?></td>
            <td><?php echo $booking['book_time']; ?></td>
            <td>
                <?php if ($booking['is_confirmed'] == 0): ?>
                    <span class="status-unconfirmed">未确认</span>
                <?php else: ?>
                    <span class="status-confirmed">已确认</span>
                <?php endif; ?>
            </td>
            <td><?php echo $booking['actual_price'] ? number_format($booking['actual_price'], 2) : '待设置'; ?></td>
            <td>
                <?php if ($booking['is_paid'] == 0): ?>
                    <span class="status-unpaid">未付款</span>
                <?php else: ?>
                    <span class="status-paid">已付款</span>
                <?php endif; ?>
            </td>
            <td>
                <?php if ($booking['is_completed'] == 0): ?>
                    <span class="status-uncompleted">未完成</span>
                <?php else: ?>
                    <span class="status-completed">已完成</span>
                <?php endif; ?>
            </td>
            <td>
                <?php if ($booking['is_confirmed'] == 0): ?>
                    <button class="action-btn confirm-btn" onclick="openBookModal(<?php echo $booking['id']; ?>)">确认预约</button>
                <?php else: ?>
                    <button class="action-btn confirm-btn" onclick="openBookStatusModal(<?php echo $booking['id']; ?>, <?php echo $booking['is_paid']; ?>, <?php echo $booking['is_completed']; ?>)">修改状态</button>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; ?>
<?php endif; ?>