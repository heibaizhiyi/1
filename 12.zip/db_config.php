<?php
// 数据库配置
$host = 'localhost';     // 数据库地址
$db_user = 'root';       // 数据库用户名（默认root）
$db_pass = '123456';           // 数据库密码（默认空，需根据实际修改）
$db_name = 'barbershop'; // 数据库名

// 创建连接
$conn = mysqli_connect($host, $db_user, $db_pass, $db_name);

// 检查连接
if (!$conn) {
    die("数据库连接失败: " . mysqli_connect_error());
}

// 设置字符集
mysqli_set_charset($conn, 'utf8');

// 检查并添加商家对外显示名字段
$check_column = mysqli_query($conn, "SHOW COLUMNS FROM members LIKE 'merchant_display_name'");
if (mysqli_num_rows($check_column) == 0) {
    // 添加字段
    mysqli_query($conn, "ALTER TABLE members ADD COLUMN merchant_display_name VARCHAR(100) NULL DEFAULT NULL");
    // 设置默认值
    mysqli_query($conn, "UPDATE members SET merchant_display_name = '店长' WHERE merchant_username IS NOT NULL");
}

// 检查并添加is_admin字段
$check_column = mysqli_query($conn, "SHOW COLUMNS FROM members LIKE 'is_admin'");
if (mysqli_num_rows($check_column) == 0) {
    // 添加字段
    mysqli_query($conn, "ALTER TABLE members ADD COLUMN is_admin TINYINT(1) NOT NULL DEFAULT 0");
    // 设置当前admin账户的is_admin为1
    if (isset($_SESSION['admin_id'])) {
        mysqli_query($conn, "UPDATE members SET is_admin = 1 WHERE id = " . $_SESSION['admin_id']);
    }
}
?>
