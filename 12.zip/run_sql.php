<?php
include 'db_config.php';

// 读取SQL文件
$sql = file_get_contents('update_db_display_name.sql');

// 执行SQL
if (mysqli_multi_query($conn, $sql)) {
    echo "SQL执行成功！";
} else {
    echo "SQL执行失败: " . mysqli_error($conn);
}

// 关闭连接
mysqli_close($conn);
?>