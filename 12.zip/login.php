<?php
session_start();
// 已登录则直接跳转
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header('Location: admin_dashboard.php');
    exit;
}
if (isset($_SESSION['customer_logged_in']) && $_SESSION['customer_logged_in'] === true) {
    header('Location: customer_center.php');
    exit;
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include 'db_config.php';
    $account = trim($_POST['account']);
    $password = trim($_POST['password']);
    
    // 首先检查是否是管理员账号
    $admin_sql = 'SELECT * FROM admin WHERE username = ?';
    $admin_stmt = mysqli_prepare($conn, $admin_sql);
    mysqli_stmt_bind_param($admin_stmt, 's', $account);
    mysqli_stmt_execute($admin_stmt);
    $admin = mysqli_fetch_assoc(mysqli_stmt_get_result($admin_stmt));
    
    if ($admin && $password == $admin['password']) {
        // 管理员登录成功
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = $admin['username'];
        $_SESSION['admin_id'] = $admin['id'];
        header('Location: admin_dashboard.php');
        exit;
    }
    
    // 检查是否是客户手机号
    $regex = '/^1[3-9]\d{9}$/';
    if (preg_match($regex, $account)) {
        // 是手机号，查询客户
        $customer_sql = 'SELECT * FROM members WHERE phone = ? AND is_customer = 1';
        $customer_stmt = mysqli_prepare($conn, $customer_sql);
        mysqli_stmt_bind_param($customer_stmt, 's', $account);
        mysqli_stmt_execute($customer_stmt);
        $customer = mysqli_fetch_assoc(mysqli_stmt_get_result($customer_stmt));
        
        if ($customer && $password == $customer['password']) {
            // 客户登录成功
            $_SESSION['customer_logged_in'] = true;
            $_SESSION['customer_id'] = $customer['id'];
            $_SESSION['customer_name'] = $customer['name'];
            $_SESSION['customer_phone'] = $customer['phone'];
            $_SESSION['is_member'] = $customer['is_member'];
            $_SESSION['member_level'] = $customer['member_level'];
            $_SESSION['member_expire_time'] = $customer['member_expire_time'];
            $_SESSION['customer_avatar'] = $customer['avatar'] ?? '';
            header('Location: customer_center.php');
            exit;
        }
    } else {
        // 不是手机号，尝试查询客户用户名
        $customer_sql = 'SELECT * FROM members WHERE name = ? AND is_customer = 1';
        $customer_stmt = mysqli_prepare($conn, $customer_sql);
        mysqli_stmt_bind_param($customer_stmt, 's', $account);
        mysqli_stmt_execute($customer_stmt);
        $customer = mysqli_fetch_assoc(mysqli_stmt_get_result($customer_stmt));
        
        if ($customer && $password == $customer['password']) {
            // 客户登录成功
            $_SESSION['customer_logged_in'] = true;
            $_SESSION['customer_id'] = $customer['id'];
            $_SESSION['customer_name'] = $customer['name'];
            $_SESSION['customer_phone'] = $customer['phone'];
            $_SESSION['is_member'] = $customer['is_member'];
            $_SESSION['member_level'] = $customer['member_level'];
            $_SESSION['member_expire_time'] = $customer['member_expire_time'];
            $_SESSION['customer_avatar'] = $customer['avatar'] ?? '';
            header('Location: customer_center.php');
            exit;
        }
    }
    
    // 登录失败
    $error = '账号或密码错误，请检查后重试';
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>理发店管理系统 - 登录</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <!-- 背景图 -->
    <div class="login-bg">
        <img src="https://picsum.photos/id/1005/1920/1080" alt="登录背景" class="bg-img">
        <div class="bg-overlay"></div>
    </div>
    <!-- 登录卡片 -->
    <div class="login-card">
        <div class="login-header">
            <div class="logo">
                <div class="logo-icon">理</div>
                <div class="logo-title">理发店管理系统</div>
                <div class="logo-subtitle">专业美发服务管理平台</div>
            </div>
        </div>
        <div class="login-content">
            <!-- 统一登录表单 -->
            <div class="tab-content active">
                <?php if ($error): ?>
                    <div class="error-message"><?php echo $error; ?></div>
                <?php endif; ?>
                <form method="POST" class="login-form" id="login-form">
                    <div class="form-item">
                        <input type="text" id="login_account" name="account" required placeholder="账号/手机号" class="input-field">
                        <label for="login_account" class="input-label">账号/手机号</label>
                        <div class="tip-text">请输入您的账号或手机号</div>
                    </div>
                    <div class="form-item">
                        <input type="password" id="login_password" name="password" required placeholder="密码" class="input-field">
                        <label for="login_password" class="input-label">密码</label>
                    </div>
                    <button type="submit" class="submit-btn">登录</button>
                </form>
                <div class="register-link">
                    还没有账号？<a href="register.php">立即注册</a>
                </div>
            </div>
        </div>
        <div class="login-footer">
            <a href="index.php" class="back-home">返回首页</a>
        </div>
    </div>
    <script>
        // 输入框聚焦效果
        document.querySelectorAll('.input-field').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.classList.add('focused');
            });
            input.addEventListener('blur', function() {
                if (this.value === '') {
                    this.parentElement.classList.remove('focused');
                }
            });
            // 初始化
            if (input.value !== '') {
                input.parentElement.classList.add('focused');
            }
        });
    </script>
</body>
</html>
