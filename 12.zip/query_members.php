<?php
include 'db_config.php';

// 查询members表
$sql = "SELECT * FROM members";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    echo "members表数据：\n";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "ID: " . $row["id"] . "，姓名: " . $row["name"] . "，手机号: " . $row["phone"] . "，是否客户: " . $row["is_customer"] . "\n";
    }
} else {
    echo "members表没有数据\n";
}

mysqli_close($conn);
?>