<?php
session_start();
if (!isset($_SESSION['customer_logged_in']) || $_SESSION['customer_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}
include 'db_config.php';
$customer_id = $_SESSION['customer_id'];
$message = '';
$message_type = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['avatar'])) {
    $file = $_FILES['avatar'];
    // 检查文件是否有错误
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $message = '文件上传失败，请重试';
        $message_type = 'error';
    } else {
        // 检查文件类型
        $file_type = mime_content_type($file['tmp_name']);
        if (strpos($file_type, 'image/') !== 0) {
            $message = '请上传图片文件';
            $message_type = 'error';
        } else {
            // 检查文件大小
            if ($file['size'] > 2 * 1024 * 1024) { // 2MB
                $message = '图片大小不能超过2MB';
                $message_type = 'error';
            } else {
                // 创建uploads目录
                $upload_dir = 'uploads/';
                if (!file_exists($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }
                // 生成唯一文件名
                $file_ext = pathinfo($file['name'], PATHINFO_EXTENSION);
                $file_name = uniqid() . '.' . $file_ext;
                $file_path = $upload_dir . $file_name;
                // 移动文件
                if (move_uploaded_file($file['tmp_name'], $file_path)) {
                    // 删除旧头像
                    if (!empty($_SESSION['customer_avatar']) && file_exists($_SESSION['customer_avatar'])) {
                        unlink($_SESSION['customer_avatar']);
                    }
                    // 更新数据库
                    $update_sql = 'UPDATE members SET avatar = ? WHERE id = ?';
                    $stmt = mysqli_prepare($conn, $update_sql);
                    mysqli_stmt_bind_param($stmt, 'si', $file_path, $customer_id);
                    if (mysqli_stmt_execute($stmt)) {
                        // 更新会话
                        $_SESSION['customer_avatar'] = $file_path;
                        $message = '头像更新成功';
                        $message_type = 'success';
                    } else {
                        $message = '头像更新失败：' . mysqli_error($conn);
                        $message_type = 'error';
                        // 删除刚上传的文件
                        unlink($file_path);
                    }
                } else {
                    $message = '图片上传失败，请重试';
                    $message_type = 'error';
                }
            }
        }
    }
}
// 跳回客户中心
header('Location: customer_center.php?msg=' . urlencode($message) . '&type=' . $message_type);
exit;
?>
