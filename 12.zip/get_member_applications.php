<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    exit;
}
include 'db_config.php';
// 查询会员申请
$applications_result = mysqli_query($conn, "SELECT ma.*, m.name, m.phone FROM member_applications ma LEFT JOIN members m ON ma.customer_id = m.id WHERE ma.status = 'pending' ORDER BY ma.apply_time DESC");
if (!$applications_result) {
    $member_applications = [];
    error_log('查询会员申请失败: ' . mysqli_error($conn));
} else {
    $member_applications = mysqli_fetch_all($applications_result, MYSQLI_ASSOC);
}
?>
<tr>
    <th>申请ID</th>
    <th>客户姓名</th>
    <th>客户手机号</th>
    <th>申请时间</th>
    <th>操作</th>
</tr>
<?php if (empty($member_applications)): ?>
    <tr>
        <td colspan="5" class="no-data">暂无会员申请</td>
    </tr>
<?php else: ?>
    <?php foreach ($member_applications as $app): ?>
        <tr>
            <td><?php echo $app['id']; ?></td>
            <td><?php echo $app['name']; ?></td>
            <td><?php echo $app['phone']; ?></td>
            <td><?php echo $app['apply_time']; ?></td>
            <td>
                <a href="approve_member.php?id=<?php echo $app['id']; ?>" class="action-btn confirm-btn">通过</a>
                <a href="reject_member.php?id=<?php echo $app['id']; ?>" class="action-btn delete-btn">拒绝</a>
            </td>
        </tr>
    <?php endforeach; ?>
<?php endif; ?>