<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('HTTP/1.1 401 Unauthorized');
    exit;
}
include 'db_config.php';
// 获取待处理预约数量
$pending_bookings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM customer_package_records WHERE is_confirmed = 0"))['count'] ?? 0;
// 获取待审核会员申请数量
$pending_applications = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM member_applications WHERE status = 'pending'"))['count'] ?? 0;
// 获取未读聊天消息数量
$total_unread_chat = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM chat_messages WHERE receiver_id = {$_SESSION['admin_id']} AND sender_type = 'customer' AND is_read = 0"))['count'] ?? 0;
// 返回JSON数据
echo json_encode([
    'pending_bookings' => $pending_bookings,
    'pending_applications' => $pending_applications,
    'total_unread_chat' => $total_unread_chat
]);
?>