<?php
session_start();
// 已登录则直接跳转
if (isset($_SESSION['customer_logged_in']) && $_SESSION['customer_logged_in'] === true) {
    header('Location: customer_center.php');
    exit;
}
$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include 'db_config.php';
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    
    // 验证手机号格式
    $regex = '/^1[3-9]\d{9}$/';
    if (!preg_match($regex, $phone)) {
        $error = '请输入正确的手机号格式';
    } elseif (empty($name)) {
        $error = '姓名不能为空';
    } elseif (strlen($password) < 6) {
        $error = '密码长度不少于6位';
    } elseif ($password !== $confirm_password) {
        $error = '两次输入的密码不一致';
    } else {
        // 检查手机号是否已在members表中存在
        $member_sql = 'SELECT * FROM members WHERE phone = ?';
        $member_stmt = mysqli_prepare($conn, $member_sql);
        mysqli_stmt_bind_param($member_stmt, 's', $phone);
        mysqli_stmt_execute($member_stmt);
        $customer = mysqli_fetch_assoc(mysqli_stmt_get_result($member_stmt));
        
        // 检查手机号是否已在admin表中作为用户名存在
        $admin_sql = 'SELECT * FROM admin WHERE username = ?';
        $admin_stmt = mysqli_prepare($conn, $admin_sql);
        mysqli_stmt_bind_param($admin_stmt, 's', $phone);
        mysqli_stmt_execute($admin_stmt);
        $admin = mysqli_fetch_assoc(mysqli_stmt_get_result($admin_stmt));
        
        if ($customer || $admin) {
            $error = '该手机号已注册，请直接登录';
        } else {
            // 注册新客户
            $insert_sql = 'INSERT INTO members (name, phone, password, is_customer) VALUES (?, ?, ?, 1)';
            $stmt = mysqli_prepare($conn, $insert_sql);
            mysqli_stmt_bind_param($stmt, 'sss', $name, $phone, $password);
            if (mysqli_stmt_execute($stmt)) {
                $success = '注册成功！请登录';
                // 跳转到登录页面
                header('Location: login.php?msg=' . urlencode($success) . '&type=success');
                exit;
            } else {
                $error = '注册失败，请稍后重试';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>理发店管理系统 - 客户注册</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <!-- 背景图 -->
    <div class="login-bg">
        <img src="https://picsum.photos/id/1005/1920/1080" alt="注册背景" class="bg-img">
        <div class="bg-overlay"></div>
    </div>
    <!-- 注册卡片 -->
    <div class="login-card">
        <div class="login-header">
            <div class="logo">
                <div class="logo-icon">理</div>
                <div class="logo-title">理发店管理系统</div>
                <div class="logo-subtitle">专业美发服务管理平台</div>
            </div>
            <h2 class="register-title">客户注册</h2>
        </div>
        <div class="login-content">
            <?php if ($error): ?>
                <div class="error-message"><?php echo $error; ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="success-message"><?php echo $success; ?></div>
            <?php endif; ?>
            <form method="POST" class="login-form">
                <div class="form-item">
                    <input type="text" id="name" name="name" required placeholder="姓名" value="<?php echo isset($_POST['name']) ? $_POST['name'] : ''; ?>" class="input-field">
                    <label for="name" class="input-label">姓名</label>
                </div>
                <div class="form-item">
                    <input type="tel" id="phone" name="phone" required placeholder="手机号" value="<?php echo isset($_POST['phone']) ? $_POST['phone'] : ''; ?>" class="input-field">
                    <label for="phone" class="input-label">手机号</label>
                    <div class="tip-text">请输入真实手机号，用于登录和接收通知</div>
                </div>
                <div class="form-item">
                    <input type="password" id="password" name="password" required placeholder="设置密码" class="input-field">
                    <label for="password" class="input-label">设置密码</label>
                    <div class="tip-text">密码长度不少于6位</div>
                </div>
                <div class="form-item">
                    <input type="password" id="confirm_password" name="confirm_password" required placeholder="确认密码" class="input-field">
                    <label for="confirm_password" class="input-label">确认密码</label>
                    <div class="tip-text">请再次输入密码</div>
                </div>
                <button type="submit" class="submit-btn">注册</button>
            </form>
            <div class="register-link">
                已有账号？<a href="login.php">立即登录</a>
            </div>
        </div>
        <div class="login-footer">
            <a href="index.php" class="back-home">返回首页</a>
        </div>
    </div>
    <script>
        // 输入框聚焦效果
        document.querySelectorAll('.input-field').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.classList.add('focused');
            });
            input.addEventListener('blur', function() {
                if (this.value === '') {
                    this.parentElement.classList.remove('focused');
                }
            });
            // 初始化
            if (input.value !== '') {
                input.parentElement.classList.add('focused');
            }
        });
    </script>
</body>
</html>
