<?php
session_start();
// 清除客户会话数据
session_unset();
session_destroy();
// 跳转到客户登录页面
header('Location: login.php#customer-tab');
exit;
?>
