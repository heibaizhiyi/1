<?php
session_start();
// 清除店长会话数据
session_unset();
session_destroy();
// 跳转到店长登录页面
header('Location: login.php#admin-tab');
exit;
?>
