<?php
session_start();
if (!isset($_SESSION['customer_logged_in']) && !isset($_SESSION['admin_logged_in'])) {
    exit;
}

include 'db_config.php';

$customer_id = intval($_GET['customer_id']);
$admin_id = $_SESSION['admin_id'] ?? 1; // 店长ID

// 获取商家信息
$merchant_username = '店长';
$merchant_display_name = '店长';
$merchant_stmt = mysqli_prepare($conn, "SELECT merchant_username, merchant_display_name FROM members WHERE id = 1 LIMIT 1");
if ($merchant_stmt) {
    if (mysqli_stmt_execute($merchant_stmt)) {
        $merchant_result = mysqli_stmt_get_result($merchant_stmt);
        if ($merchant_result) {
            $merchant = mysqli_fetch_assoc($merchant_result);
            if ($merchant && !empty($merchant['merchant_username'])) {
                $merchant_username = $merchant['merchant_username'];
            }
            if ($merchant && !empty($merchant['merchant_display_name'])) {
                $merchant_display_name = $merchant['merchant_display_name'];
            }
        }
    }
    mysqli_stmt_close($merchant_stmt);
}

// 获取聊天记录
if (isset($_SESSION['customer_logged_in'])) {
    $chat_messages = mysqli_fetch_all(mysqli_query($conn, "SELECT cm.*, CASE WHEN cm.sender_type = 'admin' THEN '$merchant_display_name' ELSE '$_SESSION[customer_name]' END AS sender_name FROM chat_messages cm WHERE (cm.sender_id = $customer_id AND cm.receiver_id = $admin_id) OR (cm.sender_id = $admin_id AND cm.receiver_id = $customer_id) ORDER BY cm.send_time ASC"), MYSQLI_ASSOC);
} elseif (isset($_SESSION['admin_logged_in'])) {
    $chat_messages = mysqli_fetch_all(mysqli_query($conn, "SELECT cm.*, CASE WHEN cm.sender_type = 'admin' THEN '$merchant_display_name' ELSE (SELECT name FROM members WHERE id = cm.sender_id) END AS sender_name FROM chat_messages cm WHERE (cm.sender_id = $_SESSION[admin_id] AND cm.receiver_id = $customer_id) OR (cm.sender_id = $customer_id AND cm.receiver_id = $_SESSION[admin_id]) ORDER BY cm.send_time ASC"), MYSQLI_ASSOC);
}

// 输出聊天记录
foreach ($chat_messages as $msg) {
    if (isset($_SESSION['customer_logged_in'])) {
        $class = $msg['sender_type'] === 'admin' ? 'received' : 'sent';
        $avatar_char = $msg['sender_type'] === 'admin' ? mb_substr($merchant_display_name, 0, 1) : mb_substr($msg['sender_name'], 0, 1);
        $sender_name = $msg['sender_type'] === 'admin' ? $merchant_display_name : $msg['sender_name'];
        echo "<div class='chat-message $class'>
                <div class='chat-avatar'>$avatar_char</div>
                <div class='message-content'>
                    <div class='sender'>$sender_name</div>
                    <div class='message-text'>{$msg['message']}</div>
                    <div class='message-time'>" . date('Y-m-d H:i', strtotime($msg['send_time'])) . "</div>
                </div>
              </div>";
    } elseif (isset($_SESSION['admin_logged_in'])) {
        $class = $msg['sender_type'] === 'admin' ? 'sent' : 'received';
        $avatar_char = $msg['sender_type'] === 'admin' ? mb_substr($merchant_display_name, 0, 1) : mb_substr($msg['sender_name'], 0, 1);
        echo "<div class='chat-message $class'>
                <div class='chat-avatar'>$avatar_char</div>
                <div class='message-content'>
                    <div class='sender'>{$msg['sender_name']}</div>
                    <div class='message-text'>{$msg['message']}</div>
                    <div class='message-time'>" . date('Y-m-d H:i', strtotime($msg['send_time'])) . "</div>
                </div>
              </div>";
    }
}

// 更新消息为已读
if (isset($_SESSION['customer_logged_in'])) {
    $update_read_sql = 'UPDATE chat_messages SET is_read = 1 WHERE receiver_id = ? AND sender_type = \'admin\'';
    $stmt = mysqli_prepare($conn, $update_read_sql);
    mysqli_stmt_bind_param($stmt, 'i', $customer_id);
    mysqli_stmt_execute($stmt);
} elseif (isset($_SESSION['admin_logged_in'])) {
    $update_read_sql = 'UPDATE chat_messages SET is_read = 1 WHERE receiver_id = ? AND sender_type = \'customer\'';
    $stmt = mysqli_prepare($conn, $update_read_sql);
    mysqli_stmt_bind_param($stmt, 'i', $_SESSION['admin_id']);
    mysqli_stmt_execute($stmt);
}
?>
