<?php
session_start();
// 检查是否登录
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php#admin-tab');
    exit;
}

include 'db_config.php';
$message = '';
$message_type = '';

// 处理添加会员
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_member'])) {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $initial_spend = floatval($_POST['initial_spend']);

    if (empty($name) || empty($phone)) {
        $message = '姓名和手机号不能为空！';
        $message_type = 'error';
    } else {
        // 检查手机号是否已存在
        $check_sql = 'SELECT id FROM members WHERE phone = ?';
        $stmt = mysqli_prepare($conn, $check_sql);
        mysqli_stmt_bind_param($stmt, 's', $phone);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        if (mysqli_num_rows($result) > 0) {
            $message = '该手机号已存在！';
            $message_type = 'error';
        } else {
            $insert_sql = 'INSERT INTO members (name, phone, total_spend) VALUES (?, ?, ?)';
            $stmt = mysqli_prepare($conn, $insert_sql);
            mysqli_stmt_bind_param($stmt, 'ssd', $name, $phone, $initial_spend);
            if (mysqli_stmt_execute($stmt)) {
                $message = '会员添加成功！';
                $message_type = 'success';
            } else {
                $message = '添加失败：' . mysqli_error($conn);
                $message_type = 'error';
            }
        }
    }
}

// 处理删除会员
if (isset($_GET['delete_member_id'])) {
    $delete_id = intval($_GET['delete_member_id']);
    $delete_sql = 'DELETE FROM members WHERE id = ?';
    $stmt = mysqli_prepare($conn, $delete_sql);
    mysqli_stmt_bind_param($stmt, 'i', $delete_id);
    if (mysqli_stmt_execute($stmt)) {
        $message = '会员删除成功！';
        $message_type = 'success';
    } else {
        $message = '删除失败：' . mysqli_error($conn);
        $message_type = 'error';
    }
    header('Location: admin_dashboard.php?msg=' . urlencode($message) . '&type=' . $message_type);
    exit;
}

// 处理编辑会员
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_member'])) {
    $member_id = intval($_POST['member_id']);
    $member_level = trim($_POST['member_level']);
    $member_expire_time = trim($_POST['member_expire_time']);
    $is_member = intval($_POST['is_member']);
    
    // 更新会员信息
    $update_sql = 'UPDATE members SET member_level = ?, member_expire_time = ?, is_member = ?, update_time = NOW() WHERE id = ?';
    $stmt = mysqli_prepare($conn, $update_sql);
    mysqli_stmt_bind_param($stmt, 'ssii', $member_level, $member_expire_time, $is_member, $member_id);
    if (mysqli_stmt_execute($stmt)) {
        $message = '会员信息修改成功！';
        $message_type = 'success';
    } else {
        $message = '修改失败：' . mysqli_error($conn);
        $message_type = 'error';
    }
    // 刷新页面
    header('Location: admin_dashboard.php?tab=member-tab');
    exit;
}

// 处理添加消费记录
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_spend'])) {
    $member_id = intval($_POST['member_id']);
    $spend_amount = floatval($_POST['spend_amount']);

    if ($spend_amount <= 0) {
        $message = '消费金额必须大于0！';
        $message_type = 'error';
    } else {
        // 更新会员消费金额
        $update_sql = 'UPDATE members SET total_spend = total_spend + ? WHERE id = ?';
        $stmt = mysqli_prepare($conn, $update_sql);
        mysqli_stmt_bind_param($stmt, 'di', $spend_amount, $member_id);
        if (mysqli_stmt_execute($stmt)) {
            $message = '消费记录添加成功！';
            $message_type = 'success';
        } else {
            $message = '添加失败：' . mysqli_error($conn);
            $message_type = 'error';
        }
    }
}

// 处理确认预约
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_book'])) {
    $book_id = intval($_POST['book_id']);
    $actual_price = floatval($_POST['actual_price']);

    if ($actual_price <= 0) {
        $message = '实际消费金额必须大于0！';
        $message_type = 'error';
    } else {
        $update_sql = 'UPDATE customer_package_records SET is_confirmed = 1, actual_price = ? WHERE id = ?';
        $stmt = mysqli_prepare($conn, $update_sql);
        mysqli_stmt_bind_param($stmt, 'di', $actual_price, $book_id);
        if (mysqli_stmt_execute($stmt)) {
            // 同时更新会员的累计消费
            $book_sql = 'SELECT customer_id FROM customer_package_records WHERE id = ?';
            $stmt = mysqli_prepare($conn, $book_sql);
            mysqli_stmt_bind_param($stmt, 'i', $book_id);
            mysqli_stmt_execute($stmt);
            $book = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
            $update_member_sql = 'UPDATE members SET total_spend = total_spend + ? WHERE id = ?';
            $stmt = mysqli_prepare($conn, $update_member_sql);
            mysqli_stmt_bind_param($stmt, 'di', $actual_price, $book['customer_id']);
            mysqli_stmt_execute($stmt);

            $message = '预约确认成功！';
            $message_type = 'success';
            // 刷新页面
            header('Location: admin_dashboard.php?tab=book-tab');
            exit;
        } else {
            $message = '确认失败：' . mysqli_error($conn);
            $message_type = 'error';
        }
    }
}

// 处理修改订单状态
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_book_status'])) {
    $book_id = intval($_POST['book_id']);
    $is_paid = intval($_POST['is_paid']);
    $is_completed = intval($_POST['is_completed']);

    $update_sql = 'UPDATE customer_package_records SET is_paid = ?, is_completed = ? WHERE id = ?';
    $stmt = mysqli_prepare($conn, $update_sql);
    mysqli_stmt_bind_param($stmt, 'iii', $is_paid, $is_completed, $book_id);
    if (mysqli_stmt_execute($stmt)) {
        $message = '订单状态更新成功！';
        $message_type = 'success';
    } else {
        $message = '更新失败：' . mysqli_error($conn);
        $message_type = 'error';
    }
}

// 处理店长发送聊天消息
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_admin_msg'])) {
    $receiver_id = intval($_POST['receiver_id']);
    $message_content = trim($_POST['message_content']);
    $sender_id = $_SESSION['admin_id'];

    if (!empty($message_content)) {
        $insert_sql = 'INSERT INTO chat_messages (sender_id, receiver_id, message, sender_type) VALUES (?, ?, ?, "admin")';
        $stmt = mysqli_prepare($conn, $insert_sql);
        mysqli_stmt_bind_param($stmt, 'iis', $sender_id, $receiver_id, $message_content);
        if (mysqli_stmt_execute($stmt)) {
            $message = '消息发送成功！';
            $message_type = 'success';
        } else {
            $message = '发送失败：' . mysqli_error($conn);
            $message_type = 'error';
        }
    }
}

// 处理新增套餐
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_package'])) {
    $package_name = trim($_POST['package_name']);
    $package_description = trim($_POST['package_description']);
    $default_price = floatval($_POST['default_price']);
    $is_enable = intval($_POST['is_enable']);

    // 处理图片上传
    $image_url = '';
    if (isset($_FILES['package_image']) && $_FILES['package_image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        $file_name = uniqid() . '_' . basename($_FILES['package_image']['name']);
        // 防止注入，过滤文件名
        $file_name = preg_replace("/[^a-zA-Z0-9_\-\.]/", "", $file_name);
        $file_path = $upload_dir . $file_name;
        $file_type = mime_content_type($_FILES['package_image']['tmp_name']);
        // 验证文件类型
        if (substr($file_type, 0, 6) === 'image/' && $_FILES['package_image']['size'] <= 2 * 1024 * 1024) {
            if (move_uploaded_file($_FILES['package_image']['tmp_name'], $file_path)) {
                $image_url = $file_path;
            } else {
                $message = '图片上传失败';
                $message_type = 'error';
            }
        } else {
            $message = '图片格式错误或大小超过2MB';
            $message_type = 'error';
        }
    }

    if (empty($message) && (empty($package_name) || $default_price < 0)) {
        $message = '套餐名称不能为空，价格不能小于0！';
        $message_type = 'error';
    }

    if (empty($message)) {
        $insert_sql = 'INSERT INTO packages (package_name, package_description, default_price, is_enable, image_url) VALUES (?, ?, ?, ?, ?)';
        $stmt = mysqli_prepare($conn, $insert_sql);
        mysqli_stmt_bind_param($stmt, 'ssdis', $package_name, $package_description, $default_price, $is_enable, $image_url);
        if (mysqli_stmt_execute($stmt)) {
            $message = '套餐添加成功！';
            $message_type = 'success';
        } else {
            $message = '添加失败：' . mysqli_error($conn);
            $message_type = 'error';
        }
    }
}

// 处理编辑套餐
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_package'])) {
    $package_id = intval($_POST['package_id']);
    $package_name = trim($_POST['package_name']);
    $package_description = trim($_POST['package_description']);
    $default_price = floatval($_POST['default_price']);
    $is_enable = intval($_POST['is_enable']);
    $old_image = $_POST['old_image'];

    if (empty($package_name) || $default_price < 0) {
        $message = '套餐名称不能为空，价格不能小于0！';
        $message_type = 'error';
    } else {
        // 处理图片上传
        $image_url = $old_image;
        if (isset($_FILES['package_image']) && $_FILES['package_image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'uploads/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            // 删除旧图片
            if ($old_image && file_exists($old_image)) {
                unlink($old_image);
            }
            $file_name = uniqid() . '_' . basename($_FILES['package_image']['name']);
            $file_name = preg_replace("/[^a-zA-Z0-9_\-\.]/", "", $file_name);
            $file_path = $upload_dir . $file_name;
            $file_type = mime_content_type($_FILES['package_image']['tmp_name']);
            if (substr($file_type, 0, 6) === 'image/' && $_FILES['package_image']['size'] <= 2 * 1024 * 1024) {
                if (move_uploaded_file($_FILES['package_image']['tmp_name'], $file_path)) {
                    $image_url = $file_path;
                } else {
                    $message = '图片上传失败';
                    $message_type = 'error';
                }
            } else {
                $message = '图片格式错误或大小超过2MB';
                $message_type = 'error';
            }
        }

        if (empty($message)) {
            $update_sql = 'UPDATE packages SET package_name = ?, package_description = ?, default_price = ?, is_enable = ?, image_url = ? WHERE id = ?';
            $stmt = mysqli_prepare($conn, $update_sql);
            mysqli_stmt_bind_param($stmt, 'ssdisi', $package_name, $package_description, $default_price, $is_enable, $image_url, $package_id);
            if (mysqli_stmt_execute($stmt)) {
                $message = '套餐编辑成功！';
                $message_type = 'success';
            } else {
                $message = '编辑失败：' . mysqli_error($conn);
                $message_type = 'error';
            }
        }
    }
}

// 处理删除套餐
if (isset($_GET['delete_package_id'])) {
    $delete_id = intval($_GET['delete_package_id']);
    // 获取套餐的图片路径
    $package_sql = 'SELECT image_url FROM packages WHERE id = ?';
    $stmt = mysqli_prepare($conn, $package_sql);
    mysqli_stmt_bind_param($stmt, 'i', $delete_id);
    mysqli_stmt_execute($stmt);
    $package = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    // 删除图片
    if ($package['image_url'] && file_exists($package['image_url'])) {
        unlink($package['image_url']);
    }
    // 删除套餐
    $delete_sql = 'DELETE FROM packages WHERE id = ?';
    $stmt = mysqli_prepare($conn, $delete_sql);
    mysqli_stmt_bind_param($stmt, 'i', $delete_id);
    if (mysqli_stmt_execute($stmt)) {
        $message = '套餐删除成功！';
        $message_type = 'success';
    } else {
        $message = '删除失败：' . mysqli_error($conn);
        $message_type = 'error';
    }
    header('Location: admin_dashboard.php?msg=' . urlencode($message) . '&type=' . $message_type);
    exit;
}

// 处理会员申请审核（GET方式，旧版）
if (isset($_GET['approve_member_id'])) {
    $app_id = intval($_GET['approve_member_id']);
    // 获取申请信息
    $app_sql = 'SELECT * FROM member_applications WHERE id = ?';
    $stmt = mysqli_prepare($conn, $app_sql);
    mysqli_stmt_bind_param($stmt, 'i', $app_id);
    mysqli_stmt_execute($stmt);
    $app = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if ($app) {
        // 更新会员状态
        $update_member_sql = 'UPDATE members SET is_member = 1, member_level = \'永久会员\', member_expire_time = \'2099-12-31\', is_admin = 0 WHERE id = ?';
        $stmt = mysqli_prepare($conn, $update_member_sql);
        mysqli_stmt_bind_param($stmt, 'i', $app['customer_id']);
        mysqli_stmt_execute($stmt);

        // 更新申请状态
        $update_app_sql = 'UPDATE member_applications SET status = \'approved\', admin_id = ?, review_time = NOW() WHERE id = ?';
        $stmt = mysqli_prepare($conn, $update_app_sql);
        mysqli_stmt_bind_param($stmt, 'ii', $_SESSION['admin_id'], $app_id);
        mysqli_stmt_execute($stmt);

        $message = '会员申请已通过';
        $message_type = 'success';
    } else {
        $message = '申请不存在';
        $message_type = 'error';
    }
    header('Location: admin_dashboard.php?msg=' . urlencode($message) . '&type=' . $message_type);
    exit;
}

// 处理拒绝会员申请
if (isset($_GET['reject_member_id'])) {
    $app_id = intval($_GET['reject_member_id']);
    // 更新申请状态
    $update_app_sql = 'UPDATE member_applications SET status = \'rejected\', admin_id = ?, review_time = NOW() WHERE id = ?';
    $stmt = mysqli_prepare($conn, $update_app_sql);
    mysqli_stmt_bind_param($stmt, 'ii', $_SESSION['admin_id'], $app_id);
    if (mysqli_stmt_execute($stmt)) {
        $message = '会员申请已拒绝';
        $message_type = 'success';
    } else {
        $message = '操作失败';
        $message_type = 'error';
    }
    header('Location: admin_dashboard.php?msg=' . urlencode($message) . '&type=' . $message_type);
    exit;
}
// 处理会员申请审核（POST方式，支持提升为管理员）
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve_application'])) {
    $app_id = intval($_POST['application_id']);
    $upgrade_to_admin = isset($_POST['upgrade_to_admin']) ? 1 : 0;
    // 获取申请信息
    $app_sql = 'SELECT * FROM member_applications WHERE id = ?';
    $stmt = mysqli_prepare($conn, $app_sql);
    mysqli_stmt_bind_param($stmt, 'i', $app_id);
    mysqli_stmt_execute($stmt);
    $app = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if ($app) {
        // 更新会员状态
        $update_member_sql = 'UPDATE members SET is_member = 1, member_level = \'永久会员\', member_expire_time = \'2099-12-31\', is_admin = ? WHERE id = ?';
        $stmt = mysqli_prepare($conn, $update_member_sql);
        mysqli_stmt_bind_param($stmt, 'ii', $upgrade_to_admin, $app['customer_id']);
        mysqli_stmt_execute($stmt);

        // 更新申请状态
        $update_app_sql = 'UPDATE member_applications SET status = \'approved\', admin_id = ?, review_time = NOW() WHERE id = ?';
        $stmt = mysqli_prepare($conn, $update_app_sql);
        mysqli_stmt_bind_param($stmt, 'ii', $_SESSION['admin_id'], $app_id);
        mysqli_stmt_execute($stmt);

        $message = '会员申请已通过！';
        if ($upgrade_to_admin) {
            $message .= ' 该会员已被提升为管理员！';
        }
        $message_type = 'success';
    } else {
        $message = '申请不存在！';
        $message_type = 'error';
    }
    header('Location: admin_dashboard.php?tab=member-audit-tab&msg=' . urlencode($message) . '&type=' . $message_type);
    exit;
}
// 处理升级为管理员
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upgrade_to_admin'])) {
    $member_id = intval($_POST['member_id']);
    // 检查是否是当前admin账户
    if ($member_id == $_SESSION['admin_id']) {
        $message = '不能升级当前管理员账户！';
        $message_type = 'error';
    } else {
        // 更新会员的is_admin字段
        $update_sql = "UPDATE members SET is_admin = 1 WHERE id = ? LIMIT 1";
        $stmt = mysqli_prepare($conn, $update_sql);
        mysqli_stmt_bind_param($stmt, 'i', $member_id);
        if (mysqli_stmt_execute($stmt)) {
            $message = '会员升级为管理员成功！';
            $message_type = 'success';
            // 刷新页面
            header('Location: admin_dashboard.php?tab=settings-tab&msg=' . urlencode($message) . '&type=' . $message_type);
            exit;
        } else {
            $message = '升级失败：' . mysqli_error($conn);
            $message_type = 'error';
        }
    }
}
// 处理修改商家信息
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_merchant_info'])) {
    $new_display_name = trim($_POST['merchant_display_name']);
    if (!empty($new_display_name)) {
        // 更新商家信息
        $update_sql = "UPDATE members SET merchant_display_name = ? WHERE id = ? LIMIT 1";
        $stmt = mysqli_prepare($conn, $update_sql);
        mysqli_stmt_bind_param($stmt, 'si', $new_display_name, $_SESSION['admin_id']);
        if (mysqli_stmt_execute($stmt)) {
            $message = '商家信息更新成功！';
            $message_type = 'success';
            // 刷新页面
            header('Location: admin_dashboard.php?tab=settings-tab&msg=' . urlencode($message) . '&type=' . $message_type);
            exit;
        } else {
            $message = '更新失败：' . mysqli_error($conn);
            $message_type = 'error';
        }
    } else {
        $message = '商家对外显示名称不能为空！';
        $message_type = 'error';
    }
}

// 查询所有会员
$members_result = mysqli_query($conn, "SELECT * FROM members ORDER BY create_time DESC");
if (!$members_result) {
    $members = [];
    error_log('查询会员列表失败: ' . mysqli_error($conn));
} else {
    $members = mysqli_fetch_all($members_result, MYSQLI_ASSOC);
}
// 查询所有预约记录
$bookings_result = mysqli_query($conn, "SELECT cpr.id, m.name, m.phone, p.package_name, cpr.book_time, cpr.is_confirmed, cpr.actual_price, cpr.is_paid, cpr.is_completed FROM customer_package_records cpr LEFT JOIN members m ON cpr.customer_id = m.id LEFT JOIN packages p ON cpr.package_id = p.id ORDER BY cpr.create_time DESC");
if (!$bookings_result) {
    $bookings = [];
    error_log('查询预约记录失败: ' . mysqli_error($conn));
} else {
    $bookings = mysqli_fetch_all($bookings_result, MYSQLI_ASSOC);
}
// 查询所有客户（包含未读消息数量）
$chat_sessions_stmt = mysqli_prepare($conn, "SELECT m.id, m.name, m.phone, m.avatar, (SELECT COUNT(*) FROM chat_messages WHERE receiver_id = ? AND sender_id = m.id AND is_read = 0) as unread_count FROM members m ORDER BY m.name");
mysqli_stmt_bind_param($chat_sessions_stmt, 'i', $_SESSION['admin_id']);
mysqli_stmt_execute($chat_sessions_stmt);
$chat_sessions_result = mysqli_stmt_get_result($chat_sessions_stmt);
if (!$chat_sessions_result) {
    $chat_sessions = [];
    error_log('查询客户聊天会话失败: ' . mysqli_error($conn));
} else {
    $chat_sessions = mysqli_fetch_all($chat_sessions_result, MYSQLI_ASSOC);
}
// 查询所有套餐
$packages_result = mysqli_query($conn, "SELECT * FROM packages ORDER BY create_time DESC");
if (!$packages_result) {
    $all_packages = [];
    error_log('查询套餐列表失败: ' . mysqli_error($conn));
} else {
    $all_packages = mysqli_fetch_all($packages_result, MYSQLI_ASSOC);
}
// 查询会员申请
$applications_result = mysqli_query($conn, "SELECT ma.*, m.name, m.phone FROM member_applications ma LEFT JOIN members m ON ma.customer_id = m.id WHERE ma.status = 'pending' ORDER BY ma.apply_time DESC");
if (!$applications_result) {
    $member_applications = [];
    error_log('查询会员申请失败: ' . mysqli_error($conn));
} else {
    $member_applications = mysqli_fetch_all($applications_result, MYSQLI_ASSOC);
}

// 获取当前选中的客户聊天记录
$selected_customer_id = isset($_GET['chat_customer_id']) ? intval($_GET['chat_customer_id']) : (empty($chat_sessions) ? 0 : $chat_sessions[0]['id']);
$chat_messages = [];
if ($selected_customer_id > 0) {
    // 查询聊天记录
    $chat_stmt = mysqli_prepare($conn, "SELECT cm.*, CASE WHEN cm.sender_type = 'admin' THEN '店长' ELSE m.name END AS sender_name FROM chat_messages cm LEFT JOIN members m ON cm.sender_id = m.id WHERE (cm.sender_id = ? AND cm.receiver_id = ?) OR (cm.sender_id = ? AND cm.receiver_id = ?) ORDER BY cm.send_time ASC");
    mysqli_stmt_bind_param($chat_stmt, 'iiii', $selected_customer_id, $_SESSION['admin_id'], $_SESSION['admin_id'], $selected_customer_id);
    mysqli_stmt_execute($chat_stmt);
    $chat_result = mysqli_stmt_get_result($chat_stmt);
    if (!$chat_result) {
        $chat_messages = [];
        error_log('查询聊天记录失败: ' . mysqli_error($conn));
    } else {
        $chat_messages = mysqli_fetch_all($chat_result, MYSQLI_ASSOC);
    }
    // 更新消息为已读
    $update_read_sql = 'UPDATE chat_messages SET is_read = 1 WHERE receiver_id = ? AND sender_type = \'customer\' AND is_read = 0';
    $stmt = mysqli_prepare($conn, $update_read_sql);
    mysqli_stmt_bind_param($stmt, 'i', $_SESSION['admin_id']);
    mysqli_stmt_execute($stmt);
}

// 获取当前登录商家的信息
$merchant_info = mysqli_fetch_assoc(mysqli_query($conn, "SELECT merchant_username, merchant_display_name FROM members WHERE id = " . $_SESSION['admin_id']));
$current_merchant_username = $merchant_info['merchant_username'] ?? '店长';
$current_merchant_display_name = $merchant_info['merchant_display_name'] ?? $current_merchant_username;
// 统计数据
$total_members = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM members"))['count'] ?? 0;
$pending_bookings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM customer_package_records WHERE is_confirmed = 0"))['count'] ?? 0;
$today_spend = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(actual_price) as sum FROM customer_package_records WHERE DATE(create_time) = CURDATE() AND is_paid = 1"))['sum'] ?? 0;
$pending_applications = count($member_applications);

// 获取消息参数
if (isset($_GET['msg'])) {
    $message = $_GET['msg'];
    $message_type = $_GET['type'];
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>店长管理后台</title>
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <!-- 左侧导航栏 -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h1>理发店管理系统</h1>
        </div>
        <div class="sidebar-user">
            <div class="avatar">店</div>
            <div class="username"><?php echo $_SESSION['admin_username']; ?></div>
            <div style="font-size: 12px; opacity: 0.7;">店长</div>
        </div>
        <div class="sidebar-menu">
            <a href="#" class="menu-item active" onclick="switchTab('member-tab')">会员管理</a>
            <a href="#" class="menu-item" onclick="switchTab('book-tab')">客户预约管理
                <?php if ($pending_bookings > 0): ?>
                    <span class="unread-badge"><?php echo $pending_bookings; ?></span>
                <?php endif; ?>
            </a>
            <a href="#" class="menu-item" onclick="switchTab('chat-tab')">客户聊天管理
                <?php
                // 计算总未读聊天消息数
                $total_unread_chat = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM chat_messages WHERE receiver_id = {$_SESSION['admin_id']} AND sender_type = 'customer' AND is_read = 0"))['count'] ?? 0;
                if ($total_unread_chat > 0):
                ?>
                    <span class="unread-badge"><?php echo $total_unread_chat; ?></span>
                <?php endif; ?>
            </a>
            <a href="#" class="menu-item" onclick="switchTab('package-tab')">套餐管理</a>
            <a href="#" class="menu-item" onclick="switchTab('member-audit-tab')">会员申请审核
                <?php if ($pending_applications > 0): ?>
                    <span class="unread-badge"><?php echo $pending_applications; ?></span>
                <?php endif; ?>
            </a>
            <a href="#" class="menu-item" onclick="switchTab('settings-tab')">商家设置</a>
        </div>
        <button class="logout-btn" onclick="location.href='logout.php'">退出登录</button>
    </div>

    <!-- 右侧主内容区 -->
    <div class="main-content">
        <div class="header-content">
            <h1 id="page-title">会员管理</h1>
            <a href="index.php" class="login-btn" style="padding: 8px 16px; background-color: #6c757d; color: white; text-decoration: none; border-radius: 6px; margin-left: 10px;">返回首页</a>
        </div>

        <?php if ($message): ?>
            <div class="message <?php echo $message_type; ?>"><?php echo $message; ?></div>
        <?php endif; ?>

        <!-- 统计卡片 -->
        <div class="admin-stats">
            <div class="stat-card total-members">
                <div class="stat-title">总会员数</div>
                <div class="stat-value"><?php echo $total_members; ?></div>
                <div class="stat-subtitle">所有注册客户</div>
            </div>
            <div class="stat-card pending-bookings">
                <div class="stat-title">待处理预约</div>
                <div class="stat-value"><?php echo $pending_bookings; ?></div>
                <div class="stat-subtitle">未确认的预约</div>
            </div>
            <div class="stat-card today-spend">
                <div class="stat-title">今日消费</div>
                <div class="stat-value"><?php echo number_format($today_spend, 2); ?> 元</div>
                <div class="stat-subtitle">今日总消费金额</div>
            </div>
            <div class="stat-card pending-applications">
                <div class="stat-title">待审核会员申请</div>
                <div class="stat-value"><?php echo $pending_applications; ?></div>
                <div class="stat-subtitle">等待处理的申请</div>
            </div>
            <div class="card" style="margin-top: 20px;">
                <h2>升级为管理员</h2>
                <form method="POST">
                    <input type="hidden" name="upgrade_to_admin" value="1">
                    <div class="form-group">
                        <label for="member_id">选择要升级的会员</label>
                        <select id="member_id" name="member_id" required>
                            <?php
                            // 获取所有非admin的会员
                            $members = mysqli_fetch_all(mysqli_query($conn, "SELECT id, name, phone FROM members WHERE id != " . $_SESSION['admin_id'] . " AND is_admin != 1"), MYSQLI_ASSOC);
                            foreach ($members as $member) {
                                echo "<option value='" . $member['id'] . "'>" . $member['name'] . " (" . $member['phone'] . ")</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <button type="submit">升级为管理员</button>
                </form>
            </div>
        </div>

        <!-- 会员管理模块 -->
        <div id="member-tab" class="tab-content active">
            <div class="card">
                <h2>添加新会员</h2>
                <form method="POST">
                    <input type="hidden" name="add_member" value="1">
                    <div class="form-group">
                        <label for="name">会员姓名</label>
                        <input type="text" id="name" name="name" required placeholder="请输入会员姓名">
                    </div>
                    <div class="form-group">
                        <label for="phone">会员手机号</label>
                        <input type="tel" id="phone" name="phone" required placeholder="请输入会员手机号">
                    </div>
                    <div class="form-group">
                        <label for="initial_spend">初始消费金额（元）</label>
                        <input type="number" id="initial_spend" name="initial_spend" step="0.01" min="0" value="0.00" required>
                    </div>
                    <button type="submit">添加会员</button>
                </form>
            </div>

            <div class="card">
                <h2>会员列表</h2>
                <table>
                    <tr>
                        <th>会员ID</th>
                        <th>姓名</th>
                        <th>手机号</th>
                        <th>累计消费（元）</th>
                        <th>会员等级</th>
                        <th>是否管理员</th>
                        <th>会员到期时间</th>
                        <th>注册时间</th>
                        <th>操作</th>
                    </tr>
                    <?php if (empty($members)): ?>
                        <tr>
                            <td colspan="9" class="no-data">暂无会员数据，请添加新会员</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($members as $member): ?>
                            <tr>
                                <td><?php echo $member['id']; ?></td>
                                <td><?php echo $member['name']; ?></td>
                                <td><?php echo $member['phone']; ?></td>
                                <td><?php echo number_format($member['total_spend'], 2); ?></td>
                                <td><?php echo $member['member_level']; ?></td>
                                <td><?php echo $member['is_admin'] == 1 ? '是' : '否'; ?></td>
                                <td>
                                    <?php 
                                    if ($member['is_member'] == 0) {
                                        echo '非会员';
                                    } else {
                                        if ($member['member_expire_time'] == '2099-12-31') {
                                            echo '永久会员';
                                        } else {
                                            echo date('Y-m-d', strtotime($member['member_expire_time']));
                                        }
                                    }
                                    ?>
                                </td>
                                <td><?php echo $member['create_time']; ?></td>
                                <td>
                                    <button class="action-btn edit-btn" onclick="editMember(<?php echo $member['id']; ?>)">编辑</button>
                                    <button class="action-btn confirm-btn" onclick="openSpendModal(<?php echo $member['id']; ?>, '<?php echo $member['name']; ?>')">添加消费</button>
                                    <a href="?delete_member_id=<?php echo $member['id']; ?>" class="action-btn delete-btn" onclick="return confirm('确定要删除会员【<?php echo $member['name']; ?>】吗？')">删除</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </table>
            </div>
        </div>

        <!-- 预约管理模块 -->
        <div id="book-tab" class="tab-content">
            <div class="card">
                <h2>客户预约记录</h2>
                <table id="bookingList">
                    <tr>
                        <th>预约ID</th>
                        <th>客户姓名</th>
                        <th>客户手机号</th>
                        <th>套餐名称</th>
                        <th>预约时间</th>
                        <th>确认状态</th>
                        <th>实际价格（元）</th>
                        <th>付款状态</th>
                        <th>完成状态</th>
                        <th>操作</th>
                    </tr>
                    <?php if (empty($bookings)): ?>
                        <tr>
                            <td colspan="10" class="no-data">暂无预约记录</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($bookings as $booking): ?>
                            <tr>
                                <td><?php echo $booking['id']; ?></td>
                                <td><?php echo $booking['name']; ?></td>
                                <td><?php echo $booking['phone']; ?></td>
                                <td><?php echo $booking['package_name']; ?></td>
                                <td><?php echo $booking['book_time']; ?></td>
                                <td>
                                    <?php if ($booking['is_confirmed'] == 0): ?>
                                        <span style="color: #dc3545;">未确认</span>
                                    <?php else: ?>
                                        <span style="color: #28a745;">已确认</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $booking['actual_price'] ? number_format($booking['actual_price'], 2) : '待设置'; ?></td>
                                <td>
                                    <?php if ($booking['is_paid'] == 0): ?>
                                        <span style="color: #dc3545;">未付款</span>
                                    <?php else: ?>
                                        <span style="color: #28a745;">已付款</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($booking['is_completed'] == 0): ?>
                                        <span style="color: #dc3545;">未完成</span>
                                    <?php else: ?>
                                        <span style="color: #28a745;">已完成</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($booking['is_confirmed'] == 0): ?>
                                        <button class="action-btn confirm-btn" onclick="openBookModal(<?php echo $booking['id']; ?>)">确认预约</button>
                                    <?php else: ?>
                                        <button class="action-btn confirm-btn" onclick="openBookStatusModal(<?php echo $booking['id']; ?>, <?php echo $booking['is_paid']; ?>, <?php echo $booking['is_completed']; ?>)">修改状态</button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </table>
            </div>
        </div>

        <!-- 聊天管理模块 -->
        <div id="chat-tab" class="tab-content">
            <div class="card">
                <h2>客户聊天管理</h2>
                <div class="chat-container">
                    <div class="chat-list">
                        <h3>客户列表</h3>
                        <?php if (empty($chat_sessions)): ?>
                            <div class="no-data">暂无客户聊天记录</div>
                        <?php else: ?>
                            <?php foreach ($chat_sessions as $session): ?>
                                <div class="chat-item <?php echo $selected_customer_id == $session['id'] ? 'active' : ''; ?>" data-customer-id="<?php echo $session['id']; ?>" onclick="switchChat(<?php echo $session['id']; ?>)" style="position: relative;">
                                    <div class="customer-avatar">
                                        <?php if (!empty($session['avatar'])): ?>
                                            <img src="<?php echo $session['avatar']; ?>" alt="客户头像" class="avatar-img">
                                        <?php else: ?>
                                            <div class="avatar-icon"><?php echo mb_substr($session['name'], 0, 1); ?></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="customer-info">
                                        <div><?php echo $session['name']; ?></div>
                                        <div style="font-size: 12px; color: #666;"><?php echo $session['phone']; ?></div>
                                    </div>
                                    <?php if ($session['unread_count'] > 0): ?>
                                        <div class="unread-badge"><?php echo $session['unread_count']; ?></div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <div class="chat-area">
                        <div class="chat-header">
                            <?php if ($selected_customer): ?>
                                <div class="customer-info-header">
                                    <div class="customer-avatar-header">
                                        <?php echo mb_substr($selected_customer['name'], 0, 1); ?>
                                    </div>
                                    <div class="customer-name-header"><?php echo $selected_customer['name']; ?></div>
                                    <div class="customer-phone-header"><?php echo $selected_customer['phone']; ?></div>
                                </div>
                            <?php else: ?>
                                <div class="no-selection">请选择一个客户开始聊天</div>
                            <?php endif; ?>
                        </div>
                        <div class="chat-messages" id="chatMessages">
                            <?php if (empty($chat_messages)): ?>
                                <div class="no-data">暂无聊天记录</div>
                            <?php else: ?>
                                <?php foreach ($chat_messages as $msg): ?>
                                    <div class="chat-message <?php echo $msg['sender_type'] == 'admin' ? 'sent' : 'received'; ?>">
                                        <div class="chat-avatar">
                                            <?php echo $msg['sender_type'] == 'admin' ? '店' : mb_substr($msg['sender_name'], 0, 1); ?>
                                        </div>
                                        <div class="message-content">
                                            <div class="sender" style="font-size: 14px; font-weight: 500; margin-bottom: 4px;"><?php echo $msg['sender_name']; ?></div>
                                            <div class="message-text"><?php echo $msg['message']; ?></div>
                                        </div>
                                        <div class="message-time" style="font-size: 12px; opacity: 0.7; <?php echo $msg['sender_type'] == 'admin' ? 'margin-right: 12px; text-align: right;' : 'margin-left: 12px;'; ?>"><?php echo date('Y-m-d H:i', strtotime($msg['send_time'])); ?></div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                        <form id="chatForm" class="chat-input">
                            <input type="hidden" name="send_admin_msg" value="1">
                            <input type="hidden" name="receiver_id" value="<?php echo $selected_customer_id; ?>">
                            <input type="text" name="message_content" placeholder="请输入消息内容" required>
                            <button type="submit">发送</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- 套餐管理模块 -->
        <div id="package-tab" class="tab-content">
            <div class="card">
                <h2>添加新套餐</h2>
                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="add_package" value="1">
                    <div class="form-group">
                        <label for="package_name">套餐名称</label>
                        <input type="text" id="package_name" name="package_name" required placeholder="如：专业精剪+吹风造型">
                    </div>
                    <div class="form-group">
                        <label for="package_description">套餐详情</label>
                        <textarea id="package_description" name="package_description" rows="3" placeholder="请输入套餐详情，如包含的服务内容、时长、注意事项等"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="default_price">参考价格（元）</label>
                        <input type="number" id="default_price" name="default_price" step="0.01" min="0" required>
                    </div>
                    <div class="form-group">
                        <label for="is_enable">是否启用</label>
                        <select id="is_enable" name="is_enable" required>
                            <option value="1">启用</option>
                            <option value="0">禁用</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="package_image">套餐图片</label>
                        <input type="file" id="package_image" name="package_image" accept="image/*">
                        <div class="placeholder-tip">支持JPG、PNG格式，大小不超过2MB</div>
                    </div>
                    <button type="submit">添加套餐</button>
                </form>
            </div>

            <div class="card">
                <h2>套餐列表</h2>
                <table>
                    <tr>
                        <th>套餐ID</th>
                        <th>套餐名称</th>
                        <th>套餐图片</th>
                        <th>套餐详情</th>
                        <th>参考价格（元）</th>
                        <th>启用状态</th>
                        <th>创建时间</th>
                        <th>操作</th>
                    </tr>
                    <?php if (empty($all_packages)): ?>
                        <tr>
                            <td colspan="8" class="no-data">暂无套餐数据，请添加新套餐</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($all_packages as $package): ?>
                            <tr>
                                <td><?php echo $package['id']; ?></td>
                                <td><?php echo $package['package_name']; ?></td>
                                <td>
                                    <?php if (!empty($package['image_url'])): ?>
                                        <img src="<?php echo $package['image_url']; ?>" alt="<?php echo $package['package_name']; ?>" class="package-thumb">
                                    <?php else: ?>
                                        无图片
                                    <?php endif; ?>
                                </td>
                                <td><?php echo !empty($package['package_description']) ? mb_substr($package['package_description'], 0, 50) . (mb_strlen($package['package_description']) > 50 ? '...' : '') : '无详情'; ?></td>
                                <td><?php echo number_format($package['default_price'], 2); ?></td>
                                <td><?php echo $package['is_enable'] == 1 ? '已启用' : '已禁用'; ?></td>
                                <td><?php echo $package['create_time']; ?></td>
                                <td>
                                    <button class="action-btn confirm-btn" onclick="openPackageEditModal(
                                        <?php echo $package['id']; ?>,
                                        '<?php echo addslashes($package['package_name']); ?>',
                                        '<?php echo addslashes($package['package_description'] ?? ''); ?>',
                                        <?php echo $package['default_price']; ?>,
                                        <?php echo $package['is_enable']; ?>,
                                        '<?php echo addslashes($package['image_url'] ?? ''); ?>'
                                    )">编辑</button>
                                    <a href="?delete_package_id=<?php echo $package['id']; ?>" class="action-btn delete-btn" onclick="return confirm('确定要删除套餐【<?php echo $package['package_name']; ?>】吗？删除后相关预约记录也会受影响！')">删除</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </table>
            </div>
        </div>

        <!-- 会员申请审核模块 -->
        <div id="member-audit-tab" class="tab-content">
            <div class="card">
                <h2>会员申请审核</h2>
                <table>
                    <tr>
                        <th>申请ID</th>
                        <th>客户姓名</th>
                        <th>客户手机号</th>
                        <th>申请时间</th>
                        <th>操作</th>
                    </tr>
                    <?php if (empty($member_applications)): ?>
                        <tr>
                            <td colspan="5" class="no-data">暂无会员申请</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($member_applications as $app): ?>
                            <tr>
                                <td><?php echo $app['id']; ?></td>
                                <td><?php echo $app['name']; ?></td>
                                <td><?php echo $app['phone']; ?></td>
                                <td><?php echo $app['apply_time']; ?></td>
                                <td>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="approve_application" value="1">
                                        <input type="hidden" name="application_id" value="<?php echo $app['id']; ?>">
                                        <label style="margin-right: 8px;">
                                            <input type="checkbox" name="upgrade_to_admin" value="1"> 提升为管理员
                                        </label>
                                        <button type="submit" class="action-btn confirm-btn" onclick="return confirm('确定要同意该会员申请吗？')">同意申请</button>
                                    </form>
                                    <a href="?reject_member_id=<?php echo $app['id']; ?>" class="action-btn delete-btn" onclick="return confirm('确定要拒绝该会员申请吗？')">拒绝申请</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </table>
            </div>
        </div>
        <!-- 商家设置模块 -->
        <div id="settings-tab" class="tab-content">
            <div class="card">
                <h2>商家信息设置</h2>
                <form method="POST">
                    <input type="hidden" name="update_merchant_info" value="1">
                    <div class="form-group">
                        <label for="merchant_display_name">商家对外显示名称</label>
                        <input type="text" id="merchant_display_name" name="merchant_display_name" value="<?php echo htmlspecialchars($current_merchant_display_name); ?>" placeholder="请输入商家对外显示的名称">
                    </div>

                    <button type="submit">保存设置</button>
                </form>
            </div>
        </div>
    </div>

    <!-- 添加消费弹窗 -->
    <div id="spendModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeSpendModal()">&times;</span>
            <h3>添加消费记录</h3>
            <form method="POST">
                <input type="hidden" name="add_spend" value="1">
                <input type="hidden" id="spend_member_id" name="member_id">
                <div class="form-group">
                    <label for="spend_amount">消费金额（元）</label>
                    <input type="number" id="spend_amount" name="spend_amount" step="0.01" min="0" required>
                </div>
                <button type="submit" class="confirm-btn">确认添加</button>
                <button type="button" onclick="closeSpendModal()" style="background: #6c757d; margin-left: 10px;">取消</button>
            </form>
        </div>
    </div>

    <!-- 确认预约弹窗 -->
    <div id="bookModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeBookModal()">&times;</span>
            <h3>确认预约</h3>
            <form method="POST">
                <input type="hidden" name="confirm_book" value="1">
                <input type="hidden" id="book_id" name="book_id">
                <div class="form-group">
                    <label for="actual_price">实际消费金额（元）</label>
                    <input type="number" id="actual_price" name="actual_price" step="0.01" min="0" required>
                </div>
                <button type="submit" class="confirm-btn">确认并设置金额</button>
                <button type="button" onclick="closeBookModal()" style="background: #6c757d; margin-left: 10px;">取消</button>
            </form>
        </div>
    </div>

    <!-- 修改订单状态弹窗 -->
    <div id="bookStatusModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeBookStatusModal()">&times;</span>
            <h3>修改订单状态</h3>
            <form method="POST">
                <input type="hidden" name="update_book_status" value="1">
                <input type="hidden" id="status_book_id" name="book_id">
                <div class="form-group">
                    <label for="is_paid">付款状态</label>
                    <select id="is_paid" name="is_paid" required>
                        <option value="0">未付款</option>
                        <option value="1">已付款</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="is_completed">完成状态</label>
                    <select id="is_completed" name="is_completed" required>
                        <option value="0">未完成</option>
                        <option value="1">已完成</option>
                    </select>
                </div>
                <button type="submit" class="confirm-btn">更新状态</button>
                <button type="button" onclick="closeBookStatusModal()" style="background: #6c757d; margin-left: 10px;">取消</button>
            </form>
        </div>
    </div>

    <!-- 编辑套餐弹窗 -->
    <div id="packageEditModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closePackageEditModal()">&times;</span>
            <h3>编辑套餐</h3>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="edit_package" value="1">
                <input type="hidden" id="edit_package_id" name="package_id">
                <input type="hidden" id="edit_old_image" name="old_image">
                <div class="form-group">
                    <label for="edit_package_name">套餐名称</label>
                    <input type="text" id="edit_package_name" name="package_name" required>
                </div>
                <div class="form-group">
                    <label for="edit_package_description">套餐详情</label>
                    <textarea id="edit_package_description" name="package_description" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label for="edit_default_price">参考价格（元）</label>
                    <input type="number" id="edit_default_price" name="default_price" step="0.01" min="0" required>
                </div>
                <div class="form-group">
                    <label for="edit_is_enable">是否启用</label>
                    <select id="edit_is_enable" name="is_enable" required>
                        <option value="1">启用</option>
                        <option value="0">禁用</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="edit_package_image">套餐图片</label>
                    <input type="file" id="edit_package_image" name="package_image" accept="image/*">
                    <div id="image-preview" class="image-preview">
                        <!-- 图片预览会在这里显示 -->
                    </div>
                    <div class="placeholder-tip">支持JPG、PNG格式，大小不超过2MB</div>
                </div>
                <button type="submit" class="confirm-btn">保存修改</button>
                <button type="button" onclick="closePackageEditModal()" style="background: #6c757d; margin-left: 10px;">取消</button>
            </form>
        </div>
    </div>

    <script>
        // 标签切换功能
        function switchTab(tabId) {
            // 隐藏所有标签内容
            const tabs = document.querySelectorAll('.tab-content');
            tabs.forEach(tab => tab.classList.remove('active'));
            // 移除所有菜单的激活状态
            const menus = document.querySelectorAll('.menu-item');
            menus.forEach(menu => menu.classList.remove('active'));
            // 显示选中的标签内容
            document.getElementById(tabId).classList.add('active');
            // 激活对应的菜单
            event.target.classList.add('active');
            // 修改页面标题
            const titles = {
                'member-tab': '会员管理',
                'book-tab': '客户预约管理',
                'chat-tab': '客户聊天管理',
                'package-tab': '套餐管理',
                'member-audit-tab': '会员申请审核',
                'settings-tab': '商家设置'
            };
            document.getElementById('page-title').textContent = titles[tabId];
            
            // 当切换到对应的页面时，隐藏对应的未读徽章
            if (tabId === 'member-audit-tab') {
                const badge = document.querySelector('.menu-item[onclick="switchTab(\'member-audit-tab\')"] .unread-badge');
                if (badge) {
                    badge.style.display = 'none';
                }
            }
            if (tabId === 'book-tab') {
                const badge = document.querySelector('.menu-item[onclick="switchTab(\'book-tab\')"] .unread-badge');
                if (badge) {
                    badge.style.display = 'none';
                }
            }
            if (tabId === 'chat-tab') {
                const badge = document.querySelector('.menu-item[onclick="switchTab(\'chat-tab\')"] .unread-badge');
                if (badge) {
                    badge.style.display = 'none';
                }
            }
        }

        // 添加消费弹窗控制
        function openSpendModal(memberId, memberName) {
            document.getElementById('spend_member_id').value = memberId;
            document.getElementById('spendModal').style.display = 'block';
        }
        function closeSpendModal() {
            document.getElementById('spendModal').style.display = 'none';
        }

        // 确认预约弹窗控制
        function openBookModal(bookId) {
            document.getElementById('book_id').value = bookId;
            document.getElementById('bookModal').style.display = 'block';
        }
        function closeBookModal() {
            document.getElementById('bookModal').style.display = 'none';
        }

        // 修改订单状态弹窗控制
        function openBookStatusModal(bookId, isPaid, isCompleted) {
            document.getElementById('status_book_id').value = bookId;
            document.getElementById('is_paid').value = isPaid;
            document.getElementById('is_completed').value = isCompleted;
            document.getElementById('bookStatusModal').style.display = 'block';
        }
        function closeBookStatusModal() {
            document.getElementById('bookStatusModal').style.display = 'none';
        }

        // 编辑套餐弹窗控制
        function openPackageEditModal(packageId, packageName, packageDescription, defaultPrice, isEnable, imageUrl) {
            document.getElementById('edit_package_id').value = packageId;
            document.getElementById('edit_package_name').value = packageName;
            document.getElementById('edit_package_description').value = packageDescription;
            document.getElementById('edit_default_price').value = defaultPrice;
            document.getElementById('edit_is_enable').value = isEnable;
            document.getElementById('edit_old_image').value = imageUrl;

            // 显示图片预览
            const previewContainer = document.getElementById('image-preview');
            if (imageUrl) {
                previewContainer.innerHTML = `<img src="${imageUrl}" alt="套餐图片">`;
            } else {
                previewContainer.innerHTML = '';
            }

            document.getElementById('packageEditModal').style.display = 'block';
        }
        function closePackageEditModal() {
            document.getElementById('packageEditModal').style.display = 'none';
        }

        // 旧的跳转函数已替换为AJAX切换
        // function switchChat(customerId) {
        //     window.location.href = 'admin_dashboard.php?chat_customer_id=' + customerId;
        // }

        // 定时刷新聊天记录
        function refreshChat() {
            // 获取当前选中的客户ID
            const selectedId = localStorage.getItem('selectedChatCustomerId');
            if (!selectedId) {
                return; // 如果没有选中的客户，不刷新
            }
            const xhr = new XMLHttpRequest();
            xhr.open('GET', 'get_chat.php?customer_id=' + selectedId + '&admin_id=<?php echo $_SESSION['admin_id']; ?>', true);
            xhr.onload = function() {
                if (this.status === 200) {
                    document.getElementById('chatMessages').innerHTML = this.responseText;
                    // 滚动到底部
                    const chatMessages = document.getElementById('chatMessages');
                    chatMessages.scrollTop = chatMessages.scrollHeight;
                }
            };
            xhr.send();
        }

        // 定时刷新预约记录
        function refreshBookings() {
            const xhr = new XMLHttpRequest();
            xhr.open('GET', 'get_bookings.php', true);
            xhr.onload = function() {
                if (this.status === 200) {
                    document.getElementById('bookingList').innerHTML = this.responseText;
                }
            };
            xhr.send();
        }

        // 每10秒刷新一次预约记录
        setInterval(refreshBookings, 10000);

        // 发送消息
        document.getElementById('chatForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'send_message.php', true);
            xhr.onload = function() {
                if (this.status === 200) {
                    // 清空输入框
                    document.querySelector('input[name="message_content"]').value = '';
                    refreshChat();
                }
            };
            xhr.send(formData);
        });

        // 每1秒刷新一次聊天记录
        setInterval(refreshChat, 10000);



        // 图片预览的监听
        document.getElementById('edit_package_image').addEventListener('change', function(e) {
            const file = e.target.files[0];
            const previewContainer = document.getElementById('image-preview');
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewContainer.innerHTML = `<img src="${e.target.result}" alt="预览图片">`;
                }
                reader.readAsDataURL(file);
            } else {
                previewContainer.innerHTML = '';
            }
        });

        // 点击弹窗外区域关闭
        window.onclick = function(event) {
            if (event.target.id === 'spendModal') closeSpendModal();
            if (event.target.id === 'bookModal') closeBookModal();
            if (event.target.id === 'bookStatusModal') closeBookStatusModal();
            if (event.target.id === 'packageEditModal') closePackageEditModal();
        }

        // 切换聊天客户
        function switchChat(customerId) {
            // 保存到localStorage
            localStorage.setItem('selectedChatCustomerId', customerId);
            console.log('Switching to customer ID:', customerId);
            // 移除所有客户的激活状态
            document.querySelectorAll('.chat-item').forEach(item => {
                item.classList.remove('active');
            });
            // 激活当前客户，尝试匹配字符串和数字
            const currentItem = document.querySelector(`.chat-item[data-customer-id="${customerId}"]`) || document.querySelector(`.chat-item[data-customer-id="${parseInt(customerId)}"]`);
            console.log('Found customer item:', currentItem);
            if (currentItem) {
                currentItem.classList.add('active');
            } else {
                console.log('Customer item not found for ID:', customerId);
            }
            // 更新聊天窗口的receiver_id
            const receiverInput = document.querySelector('input[name="receiver_id"]');
            if (receiverInput) {
                receiverInput.value = customerId;
            }
            // 刷新聊天记录
            refreshChat();
        }
        // 页面加载时刷新一次
        window.onload = function() {
            // 聊天窗口自动滚动到底部
            const chatMessages = document.getElementById('chatMessages');
            if (chatMessages) {
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
            
            // 读取localStorage里的选中客户ID
            const selectedId = localStorage.getItem('selectedChatCustomerId');
            console.log('Selected ID from localStorage:', selectedId);
            if (selectedId) {
                // 查找对应的客户项
                const customerItem = document.querySelector(`.chat-item[data-customer-id="${selectedId}"]`);
                console.log('Found customer item:', customerItem);
                if (customerItem) {
                    switchChat(selectedId);
                } else {
                    console.log('Customer item not found for ID:', selectedId);
                }
            }
            // 刷新数据
            refreshChat();
            refreshBookings();
            // 图片预览的监听
            const imageInput = document.getElementById('edit_package_image');
            if (imageInput) {
                imageInput.addEventListener('change', function(e) {
                    const file = e.target.files[0];
                    const previewContainer = document.getElementById('image-preview');
                    if (file) {
                        const reader = new FileReader();
                        reader.onload = function(e) {
                            previewContainer.innerHTML = `<img src="${e.target.result}" alt="预览图片">`;
                        }
                        reader.readAsDataURL(file);
                    } else {
                        previewContainer.innerHTML = '';
                    }
                });
            }
            
            // 为未读徽章添加点击关闭事件
            document.querySelectorAll('.unread-badge').forEach(badge => {
                badge.addEventListener('click', function(e) {
                    e.stopPropagation(); // 阻止点击事件传递到父元素
                    this.style.display = 'none';
                    // 可以添加AJAX请求，标记为已读
                });
            });
            
            // 当进入对应的页面时，隐藏未读徽章
            const activeTab = document.querySelector('.tab-content.active');
            if (activeTab) {
                if (activeTab.id === 'member-audit-tab') {
                    const badge = document.querySelector('.menu-item[onclick="switchTab(\'member-audit-tab\')"] .unread-badge');
                    if (badge) {
                        badge.style.display = 'none';
                    }
                }
                if (activeTab.id === 'book-tab') {
                    const badge = document.querySelector('.menu-item[onclick="switchTab(\'book-tab\')"] .unread-badge');
                    if (badge) {
                        badge.style.display = 'none';
                    }
                }
                if (activeTab.id === 'chat-tab') {
                    const badge = document.querySelector('.menu-item[onclick="switchTab(\'chat-tab\')"] .unread-badge');
                    if (badge) {
                        badge.style.display = 'none';
                    }
                }
            }
        };
    </script>
<script>
// 定时刷新聊天记录
function refreshChat() {
    const selectedCustomerId = document.querySelector('.chat-item.active')?.dataset.customerId;
    if (!selectedCustomerId) return;
    const xhr = new XMLHttpRequest();
    xhr.open('GET', `get_chat.php?customer_id=${selectedCustomerId}&admin_id=<?php echo $_SESSION['admin_id']; ?>`, true);
    xhr.onload = function() {
        if (this.status === 200) {
            const chatMessages = document.getElementById('chatMessages');
            const newContent = this.responseText;
            if (newContent !== chatMessages.innerHTML) {
                chatMessages.innerHTML = newContent;
                // 滚动到底部
                chatMessages.scrollTop = chatMessages.scrollHeight;
                // 显示新消息提示
                if (document.hidden) {
                    // 页面在后台时显示浏览器通知
                    if (Notification.permission === 'granted') {
                        new Notification('新消息提醒', {
                            body: '有新的客户消息',
                            icon: 'favicon.ico'
                        });
                    } else if (Notification.permission !== 'denied') {
                        Notification.requestPermission().then(permission => {
                            if (permission === 'granted') {
                                new Notification('新消息提醒', {
                                    body: '有新的客户消息',
                                    icon: 'favicon.ico'
                                });
                            }
                        });
                    }
                }
            }
        }
    };
    xhr.send();
}
// 每1秒刷新一次聊天记录
setInterval(refreshChat, 10000);

// 定时刷新客户列表
function refreshCustomerList() {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', `get_customers.php?admin_id=<?php echo $_SESSION['admin_id']; ?>`, true);
    xhr.onload = function() {
        if (this.status === 200) {
            const customerList = document.querySelector('.chat-list');
            const newContent = this.responseText;
            // 找到客户列表的内容部分，替换掉原来的客户列表（除了标题）
            const customerContent = customerList.querySelector('.chat-item') ? customerList : customerList.querySelector('div');
            if (newContent !== customerContent.innerHTML) {
                customerContent.innerHTML = newContent;
                // 重新绑定点击事件
                document.querySelectorAll('.chat-item').forEach(item => {
                    item.addEventListener('click', function() {
                        switchChat(this.dataset.customerId);
                    });
                });
                // 恢复选中状态
                const selectedId = localStorage.getItem('selectedChatCustomerId');
                if (selectedId) {
                    const currentItem = document.querySelector(`.chat-item[data-customer-id="${selectedId}"]`) || document.querySelector(`.chat-item[data-customer-id="${parseInt(selectedId)}"]`);
                    if (currentItem) {
                        currentItem.classList.add('active');
                    }
                }
                // 显示新客户提示
                const unreadBadges = document.querySelectorAll('.unread-badge');
                let totalUnread = 0;
                unreadBadges.forEach(badge => {
                    totalUnread += parseInt(badge.textContent);
                });
                if (totalUnread > 0 && document.hidden) {
                    if (Notification.permission === 'granted') {
                        new Notification('新消息提醒', {
                            body: `有${totalUnread}条未读消息`,
                            icon: 'favicon.ico'
                        });
                    } else if (Notification.permission !== 'denied') {
                        Notification.requestPermission().then(permission => {
                            if (permission === 'granted') {
                                new Notification('新消息提醒', {
                                    body: `有${totalUnread}条未读消息`,
                                    icon: 'favicon.ico'
                                });
                            }
                        });
                    }
                }
            }
        }
    };
    xhr.send();
}
// 每1秒刷新一次客户列表
setInterval(refreshCustomerList, 1000);

// 定时刷新会员列表
function refreshMemberList() {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', `get_members.php`, true);
    xhr.onload = function() {
        if (this.status === 200) {
            const memberTable = document.querySelector('#member-tab table');
            const newContent = this.responseText;
            if (newContent !== memberTable.innerHTML) {
                memberTable.innerHTML = newContent;
                // 重新绑定点击事件
                document.querySelectorAll('.delete-btn').forEach(btn => {
                    btn.addEventListener('click', function() {
                        deleteMember(this.dataset.memberId);
                    });
                });
                document.querySelectorAll('.confirm-btn').forEach(btn => {
                    btn.addEventListener('click', function() {
                        openAddSpendModal(this.dataset.memberId);
                    });
                });
            }
            // 通知检查
            checkNotifications();
            // 每10秒检查一次
            setInterval(checkNotifications, 10000);
        }
    };
    xhr.send();
}
// 每1秒刷新一次会员列表
setInterval(refreshMemberList, 1000);

// 定时刷新预约记录
function refreshBookingList() {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', `get_bookings.php`, true);
    xhr.onload = function() {
        if (this.status === 200) {
            const bookingTable = document.querySelector('#book-tab table');
            const newContent = this.responseText;
            if (newContent !== bookingTable.innerHTML) {
                bookingTable.innerHTML = newContent;
                // 重新绑定点击事件
                document.querySelectorAll('.action-btn').forEach(btn => {
                    if (btn.classList.contains('confirm-btn')) {
                        btn.addEventListener('click', function() {
                            if (this.textContent === '确认预约') {
                                openBookModal(this.dataset.bookId);
                            } else {
                                openBookStatusModal(this.dataset.bookId);
                            }
                        });
                    }
                });
            }
            // 通知检查
            checkNotifications();
            // 每10秒检查一次
            setInterval(checkNotifications, 10000);
        }
    };
    xhr.send();
}
// 每1秒刷新一次预约记录
setInterval(refreshBookingList, 1000);

// 定时刷新会员申请
function refreshMemberApplications() {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', `get_member_applications.php`, true);
    xhr.onload = function() {
        if (this.status === 200) {
            const applicationTable = document.querySelector('#member-audit-tab table');
            const newContent = this.responseText;
            if (newContent !== applicationTable.innerHTML) {
                applicationTable.innerHTML = newContent;
                // 显示新申请提示
                const applicationRows = document.querySelectorAll('#member-audit-tab table tr');
                if (applicationRows.length > 1 && document.hidden) {
                    // 有新申请
                    if (Notification.permission === 'granted') {
                        new Notification('新会员申请提醒', {
                            body: `有${applicationRows.length - 1}个新会员申请`,
                            icon: 'favicon.ico'
                        });
                    } else if (Notification.permission !== 'denied') {
                        Notification.requestPermission().then(permission => {
                            if (permission === 'granted') {
                                new Notification('新会员申请提醒', {
                                    body: `有${applicationRows.length - 1}个新会员申请`,
                                    icon: 'favicon.ico'
                                });
                            }
                        });
                    }
                }
            }
        }
    };
    xhr.send();
}
// 每1秒刷新一次会员申请
setInterval(refreshMemberApplications, 1000);
</script>
<script>
    // 检查未读通知
    function checkNotifications() {
        // 使用AJAX获取最新的未读数量
        fetch('get_unread_notifications.php')
            .then(response => response.json())
            .then(data => {
                const pendingBookings = data.pending_bookings;
                const pendingApplications = data.pending_applications;
                const totalUnreadChat = data.total_unread_chat;
                
                const notifications = [];
                if (pendingBookings > 0) {
                    notifications.push(`有 ${pendingBookings} 个待处理预约`);
                }
                if (pendingApplications > 0) {
                    notifications.push(`有 ${pendingApplications} 个待审核会员申请`);
                }
                if (totalUnreadChat > 0) {
                    notifications.push(`有 ${totalUnreadChat} 条未读聊天消息`);
                }
                
                // 生成通知的唯一标识，用于判断是否是新的通知
                const notificationKey = `${pendingBookings}-${pendingApplications}-${totalUnreadChat}`;
                // 获取之前保存的通知标识
                const lastNotificationKey = localStorage.getItem('lastNotificationKey');
                
                // 只有当有新的通知，且通知内容发生变化时，才显示
                if (notifications.length > 0 && notificationKey !== lastNotificationKey) {
                    // 保存当前的通知标识，避免重复显示相同的通知
                    localStorage.setItem('lastNotificationKey', notificationKey);
                    
                    // 创建通知弹窗
                    let modal = document.getElementById('notification-modal');
                    if (!modal) {
                        modal = document.createElement('div');
                        modal.id = 'notification-modal';
                        modal.className = 'modal notification-modal';
                        modal.innerHTML = `
                            <div class="modal-content notification-content">
                                <div class="modal-header">
                                    <h2>新通知</h2>
                                    <span class="close" onclick="closeNotificationModal()">&times;</span>
                                </div>
                                <div id="notification-content">
                                    ${notifications.map(notification => `<p>${notification}</p>`).join('')}
                                </div>
                            </div>
                        `;
                        document.body.appendChild(modal);
                    } else {
                        const notificationContent = document.getElementById('notification-content');
                        notificationContent.innerHTML = notifications.map(notification => `<p>${notification}</p>`).join('');
                    }
                    modal.style.display = 'block';
                    
                    // 5秒后自动关闭通知
                    setTimeout(() => {
                        closeNotificationModal();
                    }, 5000);
                }
            })
            .catch(error => console.error('获取通知失败:', error));
    }

    // 关闭通知弹窗
    function closeNotificationModal() {
        const modal = document.getElementById('notification-modal');
        if (modal) {
            // 添加淡出动画
            modal.style.animation = 'fadeOut 0.5s ease';
            setTimeout(() => {
                modal.style.display = 'none';
                // 重置动画，避免下次显示时动画失效
                modal.style.animation = '';
            }, 500);
        }
    }

    // 页面加载时检查通知

    </script>
    <!-- 编辑会员弹窗 -->
    <div id="edit-member-modal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>编辑会员信息</h2>
                <span class="close" onclick="closeEditMemberModal()">&times;</span>
            </div>
            <form id="edit-member-form" method="POST">
                <input type="hidden" name="edit_member" value="1">
                <input type="hidden" id="edit-member-id" name="member_id" value="">
                <div class="form-group">
                    <label for="edit-member-level">会员等级</label>
                    <select id="edit-member-level" name="member_level" required>
                        <option value="普通会员">普通会员</option>
                        <option value="银卡会员">银卡会员</option>
                        <option value="金卡会员">金卡会员</option>
                        <option value="永久会员">永久会员</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="edit-member-expire">会员到期时间</label>
                    <input type="datetime-local" id="edit-member-expire" name="member_expire_time" required>
                </div>
                <div class="form-group">
                    <label for="edit-is-member">是否为会员</label>
                    <select id="edit-is-member" name="is_member" required>
                        <option value="1">是</option>
                        <option value="0">否</option>
                    </select>
                </div>
                <button type="submit" class="submit-btn">保存修改</button>
            </form>
        </div>
    </div>
    <script>
    // 编辑会员
    function editMember(memberId) {
        // 获取会员信息
        const members = <?php echo json_encode($members); ?>;
        const selectedMember = members.find(m => m.id == memberId);
        if (selectedMember) {
            document.getElementById('edit-member-id').value = selectedMember.id;
            document.getElementById('edit-member-level').value = selectedMember.member_level;
            // 格式化时间为datetime-local格式
            const expireTime = new Date(selectedMember.member_expire_time);
            const formattedTime = expireTime.toISOString().slice(0, 16);
            document.getElementById('edit-member-expire').value = formattedTime;
            document.getElementById('edit-is-member').value = selectedMember.is_member;
            document.getElementById('edit-member-modal').style.display = 'block';
        }
    }

    // 关闭编辑会员弹窗
    function closeEditMemberModal() {
        document.getElementById('edit-member-modal').style.display = 'none';
    }

    // 点击弹窗外部关闭
    window.onclick = function(event) {
        const modal = document.getElementById('edit-member-modal');
        if (event.target == modal) {
            closeEditMemberModal();
        }
    }
    </script>
    </body>
</html>