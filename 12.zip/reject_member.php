<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php#admin-tab');
    exit;
}

include 'db_config.php';

$app_id = intval($_GET['id']);
// 更新申请状态
$update_app_sql = 'UPDATE member_applications SET status = \'rejected\', admin_id = ?, review_time = NOW() WHERE id = ?';
$stmt = mysqli_prepare($conn, $update_app_sql);
mysqli_stmt_bind_param($stmt, 'ii', $_SESSION['admin_id'], $app_id);
if (mysqli_stmt_execute($stmt)) {
    header('Location: admin_dashboard.php?msg=会员申请已拒绝&type=success');
} else {
    header('Location: admin_dashboard.php?msg=操作失败&type=error');
}
exit;
?>
