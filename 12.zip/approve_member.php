<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php#admin-tab');
    exit;
}

include 'db_config.php';

$app_id = intval($_GET['id']);
// 获取申请信息
$app_sql = 'SELECT * FROM member_applications WHERE id = ?';
$stmt = mysqli_prepare($conn, $app_sql);
mysqli_stmt_bind_param($stmt, 'i', $app_id);
mysqli_stmt_execute($stmt);
$app = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if ($app) {
    // 更新会员状态
    $update_member_sql = 'UPDATE members SET is_member = 1, member_level = \'永久SVIP\', member_expire_time = \'2099-12-31\' WHERE id = ?';
    $stmt = mysqli_prepare($conn, $update_member_sql);
    mysqli_stmt_bind_param($stmt, 'i', $app['customer_id']);
    mysqli_stmt_execute($stmt);

    // 更新申请状态
    $update_app_sql = 'UPDATE member_applications SET status = \'approved\', admin_id = ?, review_time = NOW() WHERE id = ?';
    $stmt = mysqli_prepare($conn, $update_app_sql);
    mysqli_stmt_bind_param($stmt, 'ii', $_SESSION['admin_id'], $app_id);
    mysqli_stmt_execute($stmt);

    header('Location: admin_dashboard.php?msg=会员申请已通过&type=success');
} else {
    header('Location: admin_dashboard.php?msg=申请不存在&type=error');
}
exit;
?>
