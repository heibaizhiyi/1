<?php
session_start();
if (!isset($_SESSION['customer_logged_in']) || $_SESSION['customer_logged_in'] !== true) {
    exit;
}
include 'db_config.php';
$customer_id = $_SESSION['customer_id'];
// 查询我的预约记录
$books_stmt = mysqli_prepare($conn, "SELECT cpr.id, p.package_name, p.package_description, p.default_price, cpr.book_time, cpr.is_confirmed, cpr.is_paid, cpr.is_completed, cpr.actual_price FROM customer_package_records cpr LEFT JOIN packages p ON cpr.package_id = p.id WHERE cpr.customer_id = ? ORDER BY cpr.create_time DESC");
mysqli_stmt_bind_param($books_stmt, 'i', $customer_id);
mysqli_stmt_execute($books_stmt);
$books_result = mysqli_stmt_get_result($books_stmt);
$my_books = mysqli_fetch_all($books_result, MYSQLI_ASSOC);
?>
<tr>
    <th>预约ID</th>
    <th>套餐名称</th>
    <th>预约时间</th>
    <th>确认状态</th>
    <th>付款状态</th>
    <th>完成状态</th>
    <th>实际价格（元）</th>
</tr>
<?php if (empty($my_books)): ?>
    <tr>
        <td colspan="7" class="no-data">暂无预约记录</td>
    </tr>
<?php else: ?>
    <?php foreach ($my_books as $book): ?>
        <tr>
            <td><?php echo $book['id']; ?></td>
            <td><?php echo $book['package_name']; ?></td>
            <td><?php echo $book['book_time']; ?></td>
            <td>
                <?php if ($book['is_confirmed'] == 0): ?>
                    <span class="status-unconfirmed">未确认</span>
                <?php else: ?>
                    <span class="status-confirmed">已确认</span>
                <?php endif; ?>
            </td>
            <td>
                <?php if ($book['is_paid'] == 0): ?>
                    <span class="status-unpaid">未付款</span>
                <?php else: ?>
                    <span class="status-paid">已付款</span>
                <?php endif; ?>
            </td>
            <td>
                <?php if ($book['is_completed'] == 0): ?>
                    <span class="status-uncompleted">未完成</span>
                <?php else: ?>
                    <span class="status-completed">已完成</span>
                <?php endif; ?>
            </td>
            <td><?php echo $book['actual_price'] ? number_format($book['actual_price'], 2) : '待设置'; ?></td>
        </tr>
    <?php endforeach; ?>
<?php endif; ?>