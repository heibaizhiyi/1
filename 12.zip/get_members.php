<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    exit;
}
include 'db_config.php';
// 查询所有会员
$members_result = mysqli_query($conn, "SELECT * FROM members ORDER BY create_time DESC");
if (!$members_result) {
    $members = [];
    error_log('查询会员列表失败: ' . mysqli_error($conn));
} else {
    $members = mysqli_fetch_all($members_result, MYSQLI_ASSOC);
}
?>
<tr>
    <th>会员ID</th>
    <th>姓名</th>
    <th>手机号</th>
    <th>累计消费（元）</th>
    <th>会员等级</th>
    <th>会员到期时间</th>
    <th>注册时间</th>
    <th>操作</th>
</tr>
<?php if (empty($members)): ?>
    <tr>
        <td colspan="8" class="no-data">暂无会员记录</td>
    </tr>
<?php else: ?>
    <?php foreach ($members as $member): ?>
        <tr>
            <td><?php echo $member['id']; ?></td>
            <td><?php echo $member['name']; ?></td>
            <td><?php echo $member['phone']; ?></td>
            <td><?php echo number_format($member['total_spend'], 2); ?></td>
            <td><?php echo $member['is_member'] ? $member['member_level'] : '非会员'; ?></td>
            <td><?php echo $member['member_expire_time'] ? $member['member_expire_time'] : '无'; ?></td>
            <td><?php echo $member['create_time']; ?></td>
            <td>
                <button class="action-btn delete-btn" onclick="deleteMember(<?php echo $member['id']; ?>)">删除</button>
                <button class="action-btn confirm-btn" onclick="openAddSpendModal(<?php echo $member['id']; ?>)">添加消费</button>
            </td>
        </tr>
    <?php endforeach; ?>
<?php endif; ?>