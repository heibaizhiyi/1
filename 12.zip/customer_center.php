<?php
session_start();
// 检查是否登录
if (!isset($_SESSION['customer_logged_in']) || $_SESSION['customer_logged_in'] !== true) {
    header('Location: login.php#customer-tab');
    exit;
}

include 'db_config.php';
// 刷新会员信息，实时更新会员状态
$refresh_member_stmt = mysqli_prepare($conn, "SELECT * FROM members WHERE id = ?");
mysqli_stmt_bind_param($refresh_member_stmt, 'i', $_SESSION['customer_id']);
mysqli_stmt_execute($refresh_member_stmt);
$refresh_member = mysqli_fetch_assoc(mysqli_stmt_get_result($refresh_member_stmt));
if ($refresh_member) {
    $_SESSION['is_member'] = $refresh_member['is_member'];
    $_SESSION['member_level'] = $refresh_member['member_level'];
    $_SESSION['member_expire_time'] = $refresh_member['member_expire_time'];
    $_SESSION['customer_avatar'] = $refresh_member['avatar'] ?? '';
}
$message = '';
$message_type = '';

// 处理套餐预约
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_package'])) {
    $package_id = intval($_POST['package_id']);
    $book_time = $_POST['book_time'];
    $customer_id = $_SESSION['customer_id'];

    // 检查预约时间是否合理（不能是过去的时间）
    if (strtotime($book_time) < time()) {
        $message = '预约时间不能是过去的时间！';
        $message_type = 'error';
    } else {
        $insert_sql = 'INSERT INTO customer_package_records (customer_id, package_id, book_time) VALUES (?, ?, ?)';
        $stmt = mysqli_prepare($conn, $insert_sql);
        mysqli_stmt_bind_param($stmt, 'iis', $customer_id, $package_id, $book_time);
        if (mysqli_stmt_execute($stmt)) {
            $message = '预约提交成功！请等待店长确认';
            $message_type = 'success';
        } else {
            $message = '预约失败：' . mysqli_error($conn);
            $message_type = 'error';
        }
    }
}

// 处理客户发送聊天消息
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_customer_msg'])) {
    $message_content = trim($_POST['message_content']);
    $sender_id = $_SESSION['customer_id'];
    $receiver_id = 1; // 店长ID，默认是1

    if (!empty($message_content)) {
        $insert_sql = 'INSERT INTO chat_messages (sender_id, receiver_id, message, sender_type) VALUES (?, ?, ?, "customer")';
        $stmt = mysqli_prepare($conn, $insert_sql);
        mysqli_stmt_bind_param($stmt, 'iis', $sender_id, $receiver_id, $message_content);
        if (mysqli_stmt_execute($stmt)) {
            $message = '消息发送成功！';
            $message_type = 'success';
        } else {
            $message = '发送失败：' . mysqli_error($conn);
            $message_type = 'error';
        }
    }
}

// 获取客户的统计数据
$spend_stmt = mysqli_prepare($conn, "SELECT total_spend FROM members WHERE id = ?");
mysqli_stmt_bind_param($spend_stmt, 'i', $_SESSION['customer_id']);
mysqli_stmt_execute($spend_stmt);
$spend_result = mysqli_stmt_get_result($spend_stmt);
$total_spend = mysqli_fetch_assoc($spend_result)['total_spend'] ?? 0;

$booking_stmt = mysqli_prepare($conn, "SELECT COUNT(*) as count FROM customer_package_records WHERE customer_id = ?");
mysqli_stmt_bind_param($booking_stmt, 'i', $_SESSION['customer_id']);
mysqli_stmt_execute($booking_stmt);
$booking_result = mysqli_stmt_get_result($booking_stmt);
$booking_count = mysqli_fetch_assoc($booking_result)['count'] ?? 0;

// 获取所有可用套餐（包含详情和图片）
$packages_stmt = mysqli_prepare($conn, "SELECT id, package_name, package_description, default_price, image_url FROM packages WHERE is_enable = 1 ORDER BY default_price ASC");
mysqli_stmt_execute($packages_stmt);
$packages_result = mysqli_stmt_get_result($packages_stmt);
$packages = mysqli_fetch_all($packages_result, MYSQLI_ASSOC);
// 获取我的预约记录（包含套餐详情）
$books_stmt = mysqli_prepare($conn, "SELECT cpr.id, p.package_name, p.package_description, p.default_price, cpr.book_time, cpr.is_confirmed, cpr.is_paid, cpr.is_completed, cpr.actual_price FROM customer_package_records cpr LEFT JOIN packages p ON cpr.package_id = p.id WHERE cpr.customer_id = ? ORDER BY cpr.create_time DESC");
mysqli_stmt_bind_param($books_stmt, 'i', $_SESSION['customer_id']);
mysqli_stmt_execute($books_stmt);
$books_result = mysqli_stmt_get_result($books_stmt);
$my_books = mysqli_fetch_all($books_result, MYSQLI_ASSOC);
// 获取商家用户名和对外显示名称
$merchant_username = '店长'; // 默认商家用户名
$merchant_display_name = '店长'; // 默认商家对外显示名称
$merchant_stmt = mysqli_prepare($conn, "SELECT merchant_username, merchant_display_name FROM members WHERE id = 1 LIMIT 1");
if ($merchant_stmt) {
    if (mysqli_stmt_execute($merchant_stmt)) {
        $merchant_result = mysqli_stmt_get_result($merchant_stmt);
        if ($merchant_result) {
            $merchant = mysqli_fetch_assoc($merchant_result);
            if ($merchant && !empty($merchant['merchant_username'])) {
                $merchant_username = $merchant['merchant_username'];
            }
            if ($merchant && !empty($merchant['merchant_display_name'])) {
                $merchant_display_name = $merchant['merchant_display_name'];
            }
        }
    }
    mysqli_stmt_close($merchant_stmt);
}

// 获取与商家的聊天记录
$admin_id = 1; // 商家ID
$chat_stmt = mysqli_prepare($conn, "SELECT cm.*, CASE WHEN cm.sender_type = 'admin' THEN ? ELSE m.name END AS sender_name FROM chat_messages cm LEFT JOIN members m ON cm.sender_id = m.id WHERE (cm.sender_id = ? AND cm.receiver_id = ?) OR (cm.sender_id = ? AND cm.receiver_id = ?) ORDER BY cm.send_time ASC");
mysqli_stmt_bind_param($chat_stmt, 'siiii', $merchant_username, $_SESSION['customer_id'], $admin_id, $admin_id, $_SESSION['customer_id']);
mysqli_stmt_execute($chat_stmt);
$chat_result = mysqli_stmt_get_result($chat_stmt);
$chat_messages = mysqli_fetch_all($chat_result, MYSQLI_ASSOC);
// 获取未读消息数量
$unread_stmt = mysqli_prepare($conn, "SELECT COUNT(*) as count FROM chat_messages WHERE receiver_id = ? AND sender_type = 'admin' AND is_read = 0");
mysqli_stmt_bind_param($unread_stmt, 'i', $_SESSION['customer_id']);
mysqli_stmt_execute($unread_stmt);
$unread_result = mysqli_stmt_get_result($unread_stmt);
$unread_count = mysqli_fetch_assoc($unread_result)['count'] ?? 0;
// 更新消息为已读
$update_read_sql = 'UPDATE chat_messages SET is_read = 1 WHERE receiver_id = ? AND sender_type = \'admin\' AND is_read = 0';
$stmt = mysqli_prepare($conn, $update_read_sql);
mysqli_stmt_bind_param($stmt, 'i', $_SESSION['customer_id']);
mysqli_stmt_execute($stmt);

// 获取消息参数
if (isset($_GET['msg'])) {
    $message = $_GET['msg'];
    $message_type = $_GET['type'];
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>客户个人中心</title>
    <link rel="stylesheet" href="css/customer.css">
</head>
<body>
    <!-- 左侧导航栏 -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h1>理发店管理系统</h1>
        </div>
        <div class="sidebar-user">
            <div class="avatar">
                <?php if (!empty($_SESSION['customer_avatar'])): ?>
                    <img src="<?php echo $_SESSION['customer_avatar']; ?>" alt="头像" class="avatar-img">
                <?php else: ?>
                    <div class="avatar-icon"><?php echo mb_substr($_SESSION['customer_name'], 0, 1); ?></div>
                <?php endif; ?>
            </div>
            <div class="username"><?php echo $_SESSION['customer_name']; ?></div>
            <div style="font-size: 12px; opacity: 0.7;">客户</div>
            <div class="member-status" style="margin-top: 8px;">
                <?php echo $_SESSION['is_member'] ? $_SESSION['member_level'] : '非会员'; ?>
            </div>
            <!-- 头像上传表单 -->
            <form method="POST" action="update_avatar.php" enctype="multipart/form-data" class="avatar-form" style="margin-top: 12px;">
                <input type="file" name="avatar" accept="image/*" id="avatar-input" style="display: none;">
                <label for="avatar-input" class="avatar-btn" style="padding: 6px 12px; font-size: 12px; background-color: #4a5568; color: white; border-radius: 4px; cursor: pointer;">更换头像</label>
                <button type="submit" class="avatar-submit" style="display: none;">上传</button>
            </form>
        </div>
        <div class="sidebar-menu">
            <a href="#" class="menu-item active" onclick="switchTab('book-tab')">套餐预约</a>
            <a href="#" class="menu-item" onclick="switchTab('record-tab')">我的预约记录</a>
            <a href="#" class="menu-item" onclick="switchTab('chat-tab')">与店长聊天
    <?php if ($unread_count > 0): ?>
        <span class="unread-badge"><?php echo $unread_count; ?></span>
    <?php endif; ?>
</a>
        </div>
        <button class="logout-btn" onclick="location.href='customer_logout.php'">退出登录</button>
    </div>

    <!-- 右侧主内容区 -->
    <div class="main-content">
        <div class="header-content">
            <h1 id="page-title">套餐预约</h1>
            <div class="header-actions">
                <a href="index.php" class="back-home-btn">返回首页</a>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="message <?php echo $message_type; ?>"><?php echo $message; ?></div>
        <?php endif; ?>

        <!-- 统计卡片 -->
        <div class="stats-grid">
            <div class="stat-card orange">
                <div class="stat-label">累计消费</div>
                <div class="stat-value"><?php echo number_format($total_spend, 2); ?> 元</div>
                <div class="stat-tag">RMB</div>
            </div>
            <div class="stat-card blue">
                <div class="stat-label">预约次数</div>
                <div class="stat-value"><?php echo $booking_count; ?></div>
                <div class="stat-tag">次</div>
            </div>
            <div class="stat-card green">
                <div class="stat-label">会员状态</div>
                <div class="stat-value">
                    <?php 
                    if ($_SESSION['is_member']) {
                        if ($_SESSION['member_level'] == '永久会员' || $_SESSION['member_expire_time'] == '2099-12-31') {
                            echo '永久会员';
                        } else {
                            echo $_SESSION['member_level'];
                        }
                    } else {
                        echo '非会员';
                    }
                    ?>
                </div>
                <div class="stat-tag">特权</div>
            </div>
        </div>

        <!-- 会员状态 -->
        <div class="member-card">
            <?php if ($_SESSION['is_member'] == 1): ?>
                <?php if ($_SESSION['member_level'] == '永久会员' || $_SESSION['member_expire_time'] == '2099-12-31'): ?>
                    <div class="member-badge permanent-member">永久会员</div>
                    <p>您是我们的永久会员，享受终身会员特权</p>
                <?php else: ?>
                    <div class="member-badge"><?php echo $_SESSION['member_level']; ?></div>
                    <p>您是我们的会员，会员到期时间：<?php echo date('Y-m-d', strtotime($_SESSION['member_expire_time'])); ?></p>
                <?php endif; ?>
                <p>会员特权：预约优先、消费折扣、免费护理等</p>
            <?php else: ?>
                <div class="non-member-badge">非会员</div>
                <p>您还不是会员，申请会员享受更多特权</p>
                <form method="POST" action="apply_member.php">
                    <button type="submit" class="apply-btn">申请开通会员</button>
                </form>
            <?php endif; ?>
        </div>

        <!-- 套餐预约模块 -->
        <div id="book-tab" class="tab-content active">
            <div class="card">
                <h2>套餐预约</h2>
                <form method="POST">
                    <input type="hidden" name="book_package" value="1">
                    <div class="form-group">
                        <label for="package_id">选择服务套餐</label>
                        <select id="package_id" name="package_id" required>
                            <option value="">请选择套餐</option>
                            <?php foreach ($packages as $package): ?>
                                <option value="<?php echo $package['id']; ?>" title="<?php echo $package['package_description'] ?? '无套餐详情'; ?>">
                                    <?php echo $package['package_name']; ?> - 参考价格：<?php echo number_format($package['default_price'], 2); ?> 元
                                    <?php if (!empty($package['package_description'])): ?>
                                        （<?php echo mb_substr($package['package_description'], 0, 20) . (mb_strlen($package['package_description']) > 20 ? '...' : ''); ?>）
                                    <?php endif; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="book_time">预约时间</label>
                        <input type="datetime-local" id="book_time" name="book_time" required value="<?php echo date('Y-m-d\TH:i'); ?>">
                        <div class="time-shortcuts">
                            <button type="button" onclick="setTime('today')" class="time-btn">今天</button>
                            <button type="button" onclick="setTime('tomorrow')" class="time-btn">明天</button>
                            <button type="button" onclick="setTime('dayafter')" class="time-btn">后天</button>
                        </div>
                        <div class="time-hint">请选择具体的预约时间，我们的营业时间是09:00-21:00</div>
                    </div>
                    <button type="submit">提交预约</button>
                </form>

                <!-- 套餐展示 -->
                <div class="service-grid">
                    <?php foreach ($packages as $package): ?>
                        <div class="service-card">
                            <?php if (!empty($package['image_url'])): ?>
                                <img src="<?php echo $package['image_url']; ?>" alt="<?php echo $package['package_name']; ?>" class="service-image">
                            <?php else: ?>
                                <img src="https://picsum.photos/id/1062/300/200" alt="<?php echo $package['package_name']; ?>" class="service-image">
                            <?php endif; ?>
                            <h3><?php echo $package['package_name']; ?></h3>
                            <p><?php echo $package['package_description'] ?? '无详情'; ?></p>
                            <div class="service-price">参考价格：¥<?php echo number_format($package['default_price'], 2); ?></div>
                            <button class="book-btn" onclick="selectPackage(<?php echo $package['id']; ?>)">预约</button>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- 我的预约记录模块 -->
        <div id="record-tab" class="tab-content">
            <div class="card">
                <h2>我的预约记录</h2>
                <div class="table-container">
            <table class="record-table">
                    <tr>
                        <th>预约ID</th>
                        <th>套餐名称</th>
                        <th>套餐详情</th>
                        <th>参考价格（元）</th>
                        <th>实际价格（元）</th>
                        <th>预约时间</th>
                        <th>确认状态</th>
                        <th>付款状态</th>
                        <th>完成状态</th>
                    </tr>
                    <?php if (empty($my_books)): ?>
                        <tr>
                            <td colspan="9" class="no-data">暂无预约记录，请先预约套餐</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($my_books as $book): ?>
                            <tr>
                                <td><?php echo $book['id']; ?></td>
                                <td><?php echo $book['package_name']; ?></td>
                                <td><?php echo !empty($book['package_description']) ? mb_substr($book['package_description'], 0, 50) . (mb_strlen($book['package_description']) > 50 ? '...' : '') : '无详情'; ?></td>
                                <td><?php echo number_format($book['default_price'], 2); ?></td>
                                <td><?php echo $book['actual_price'] ? number_format($book['actual_price'], 2) : '待店长确认'; ?></td>
                                <td><?php echo $book['book_time']; ?></td>
                                <td>
                                    <?php if ($book['is_confirmed'] == 0): ?>
                                        <span class="status-unconfirmed">未确认</span>
                                    <?php else: ?>
                                        <span class="status-confirmed">已确认</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($book['is_paid'] == 0): ?>
                                        <span class="status-unconfirmed">未付款</span>
                                    <?php else: ?>
                                        <span class="status-paid">已付款</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($book['is_completed'] == 0): ?>
                                        <span class="status-unconfirmed">未完成</span>
                                    <?php else: ?>
                                        <span class="status-completed">已完成</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </table>
        </div>
            </div>
        </div>

        <!-- 与商家聊天模块 -->
        <div id="chat-tab" class="tab-content chat-layout">
            <!-- 左侧商家列表 -->
            <div class="chat-sidebar">
                <div class="merchant-item active" data-merchant-id="<?php echo $admin_id; ?>">
                    <div class="merchant-avatar">
                        <?php echo mb_substr($merchant_display_name ?? $merchant_username, 0, 1); ?>
                    </div>
                    <div class="merchant-info">
                        <div class="merchant-name"><?php echo $merchant_display_name ?? $merchant_username; ?></div>
                        <div class="merchant-status">在线</div>
                    </div>
                </div>
            </div>
            <!-- 右侧聊天区域 -->
            <div class="chat-main">
                <div class="chat-header">
                    <h2>与<?php echo $merchant_display_name ?? $merchant_username; ?>聊天
                        <?php if ($unread_count > 0): ?>
                            <span class="unread-badge"><?php echo $unread_count; ?></span>
                        <?php endif; ?>
                    </h2>
                </div>
                <div class="chat-messages" id="chatMessages">
                    <?php if (empty($chat_messages)): ?>
                        <div class="no-data">暂无聊天记录，发送第一条消息给商家吧</div>
                    <?php else: ?>
                        <?php foreach ($chat_messages as $msg): ?>
                            <div class="chat-message <?php echo $msg['sender_type'] == 'admin' ? 'received' : 'sent'; ?>">
                                <div class="chat-avatar">
                                    <?php echo $msg['sender_type'] == 'admin' ? mb_substr($merchant_display_name ?? $merchant_username, 0, 1) : mb_substr($msg['sender_name'], 0, 1); ?>
                                </div>
                                <div class="message-content">
                                    <div class="sender"><?php echo $msg['sender_type'] == 'admin' ? ($merchant_display_name ?? $merchant_username) : $msg['sender_name']; ?></div>
                                    <div class="message-text"><?php echo $msg['message']; ?></div>
                                    <div class="message-time"><?php echo date('Y-m-d H:i', strtotime($msg['send_time'])); ?></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <form id="chatForm" class="chat-input">
                    <input type="hidden" name="send_customer_msg" value="1">
                    <input type="hidden" name="receiver_id" value="<?php echo $admin_id; ?>">
                    <input type="text" name="message_content" placeholder="请输入消息内容" required>
                    <button type="submit">发送</button>
                </form>
            </div>
        </div>
    </div>

    <script>
        // 标签切换功能
        function switchTab(tabId) {
            // 隐藏所有标签内容
            const tabs = document.querySelectorAll('.tab-content');
            tabs.forEach(tab => tab.classList.remove('active'));
            // 移除所有菜单的激活状态
            const menus = document.querySelectorAll('.menu-item');
            menus.forEach(menu => menu.classList.remove('active'));
            // 显示选中的标签内容
            document.getElementById(tabId).classList.add('active');
            // 激活对应的菜单
            event.target.classList.add('active');
            // 修改页面标题
            const titles = {
                'book-tab': '套餐预约',
                'record-tab': '我的预约记录',
                'chat-tab': '与店长聊天'
            };
            document.getElementById('page-title').textContent = titles[tabId];
        }

        // 选择套餐
        function selectPackage(packageId) {
            document.getElementById('package_id').value = packageId;
            switchTab('book-tab');
        }

        // 定时刷新聊天记录
        function refreshChat() {
            const xhr = new XMLHttpRequest();
            xhr.open('GET', 'get_chat.php?customer_id=<?php echo $_SESSION['customer_id']; ?>', true);
            xhr.onload = function() {
                if (this.status === 200) {
                    document.getElementById('chatMessages').innerHTML = this.responseText;
                    // 滚动到底部
                    const chatMessages = document.getElementById('chatMessages');
                    chatMessages.scrollTop = chatMessages.scrollHeight;
                }
            };
            xhr.send();
        }

        // 发送消息
        document.getElementById('chatForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'send_message.php', true);
            xhr.onload = function() {
                if (this.status === 200) {
                    // 清空输入框
                    document.querySelector('input[name="message_content"]').value = '';
                    refreshChat();
                }
            };
            xhr.send(formData);
        });

        // 每5秒刷新一次聊天记录
        setInterval(refreshChat, 5000);

        // 聊天窗口自动滚动到底部
        window.onload = function() {
            const chatMessages = document.getElementById('chatMessages');
            if (chatMessages) {
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
        }

        // 支持回车发送消息
        const chatInput = document.querySelector('.chat-input input');
        if (chatInput) {
            chatInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    document.getElementById('chatForm').submit();
                }
            });
        }

        // 预约时间快捷设置
        function setTime(type) {
            const now = new Date();
            let date;
            switch(type) {
                case 'today':
                    date = now;
                    break;
                case 'tomorrow':
                    date = new Date(now.getTime() + 24 * 60 * 60 * 1000);
                    break;
                case 'dayafter':
                    date = new Date(now.getTime() + 48 * 60 * 60 * 1000);
                    break;
            }
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            const hours = String(date.getHours()).padStart(2, '0');
            const minutes = String(date.getMinutes()).padStart(2, '0');
            document.getElementById('book_time').value = `${year}-${month}-${day}T${hours}:${minutes}`;
        }
        // 定时刷新我的预约记录
        function refreshMyBookings() {
            const xhr = new XMLHttpRequest();
            xhr.open('GET', `get_my_bookings.php?customer_id=<?php echo $_SESSION['customer_id']; ?>`, true);
            xhr.onload = function() {
                if (this.status === 200) {
                    const bookingTable = document.querySelector('#record-tab table');
                    const newContent = this.responseText;
                    if (newContent !== bookingTable.innerHTML) {
                        bookingTable.innerHTML = newContent;
                    }
                }
            };
            xhr.send();
        }
        // 定时刷新会员信息
        function refreshMemberInfo() {
            const xhr = new XMLHttpRequest();
            xhr.open('GET', `get_member_info.php?customer_id=<?php echo $_SESSION['customer_id']; ?>`, true);
            xhr.onload = function() {
                if (this.status === 200) {
                    const memberCard = document.querySelector('.member-card');
                    const statCard = document.querySelector('.stat-card.member-status');
                    const memberData = JSON.parse(this.responseText);
                    // 更新会员卡片
                    let newMemberCard = '';
                    if (memberData.is_member) {
                        newMemberCard = `
                            <div class="member-badge">${memberData.member_level}</div>
                            <p>您是我们的会员，会员到期时间：${memberData.member_expire_time}</p>
                            <p>会员特权：预约优先、消费折扣、免费护理等</p>
                        `;
                    } else {
                        newMemberCard = `
                            <div class="non-member-badge">非会员</div>
                            <p>您还不是会员，申请会员享受更多特权</p>
                            <form method="POST" action="apply_member.php">
                                <button type="submit" class="apply-btn">申请开通会员</button>
                            </form>
                        `;
                    }
                    if (newMemberCard !== memberCard.innerHTML) {
                        memberCard.innerHTML = newMemberCard;
                    }
                    // 更新统计卡片
                    const newStatValue = memberData.is_member ? memberData.member_level : '非会员';
                    const newStatSubtitle = memberData.is_member ? `到期时间：${memberData.member_expire_time}` : '可申请会员';
                    if (statCard.querySelector('.stat-value').textContent !== newStatValue) {
                        statCard.querySelector('.stat-value').textContent = newStatValue;
                        statCard.querySelector('.stat-subtitle').textContent = newStatSubtitle;
                    }
                    // 如果会员状态变化，刷新页面
                    if (memberData.is_member !== <?php echo $_SESSION['is_member']; ?>) {
                        window.location.reload();
                    }
                }
            };
            xhr.send();
        }
        // 每10秒刷新一次预约记录
        setInterval(refreshMyBookings, 10000);
        // 每10秒刷新一次会员信息
        setInterval(refreshMemberInfo, 10000);
    </script>
</body>
</html>
