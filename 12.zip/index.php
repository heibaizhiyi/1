<?php
session_start();
// 已登录时不再自动跳转，允许用户访问首页
// if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
//     header('Location: admin_dashboard.php');
//     exit;
// }
// if (isset($_SESSION['customer_logged_in']) && $_SESSION['customer_logged_in'] === true) {
//     header('Location: customer_center.php');
//     exit;
// }
// 连接数据库获取统计数据
include 'db_config.php';
$total_members = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM members"))['count'] ?? 0;
$today_bookings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM customer_package_records WHERE DATE(book_time) = CURDATE()"))['count'] ?? 0;
$today_spend = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(actual_price) as sum FROM customer_package_records WHERE DATE(create_time) = CURDATE() AND is_paid = 1"))['sum'] ?? 0;
$total_services = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM packages WHERE is_enable = 1"))['count'] ?? 0;
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>专业理发店 - 首页</title>
    <link rel="stylesheet" href="css/index.css">
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <div class="logo-icon">理</div>
                <div>专业理发店</div>
            </div>
            <nav class="top-nav">
                <a href="index.php" class="nav-link active">首页</a>
                <a href="#services" class="nav-link">服务项目</a>
                <a href="#about" class="nav-link">关于我们</a>
                <a href="#reviews" class="nav-link">客户评价</a>
                <?php if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true): ?>
                    <!-- 店长登录后显示 -->
                    <div class="user-menu">
                        <div class="svip-icon">
                            <img src="https://picsum.photos/id/1005/32/32" alt="升级SVIP" class="svip-img">
                            <span class="svip-text">升级SVIP</span>
                        </div>
                        <div class="user-avatar">
                            <?php if (!empty($_SESSION['admin_avatar'])): ?>
                                <img src="<?php echo $_SESSION['admin_avatar']; ?>" alt="头像" class="avatar-img">
                            <?php else: ?>
                                <div class="avatar-icon">店</div>
                            <?php endif; ?>
                            <span class="user-name"><?php echo $_SESSION['admin_username']; ?></span>
                        </div>
                        <div class="user-dropdown">
                            <div class="dropdown-header">
                                <div class="dropdown-avatar">
                                    <?php if (!empty($_SESSION['admin_avatar'])): ?>
                                        <img src="<?php echo $_SESSION['admin_avatar']; ?>" alt="头像" class="dropdown-avatar-img">
                                    <?php else: ?>
                                        <div class="dropdown-avatar-icon">店</div>
                                    <?php endif; ?>
                                </div>
                                <div class="dropdown-user-info">
                                    <div class="dropdown-username"><?php echo $_SESSION['admin_username']; ?></div>
                                    <div class="dropdown-member-status">店长账号</div>
                                </div>
                            </div>
                            <div class="divider"></div>
                            <a href="admin_dashboard.php" class="dropdown-item">管理后台</a>
                            <a href="logout.php" class="dropdown-item">退出登录</a>
                        </div>
                    </div>
                <?php elseif (isset($_SESSION['customer_logged_in']) && $_SESSION['customer_logged_in'] === true): ?>
                    <!-- 客户登录后显示 -->
                    <div class="user-menu">
                        <div class="svip-icon">
                            <img src="https://picsum.photos/id/1005/32/32" alt="升级SVIP" class="svip-img">
                            <span class="svip-text">升级SVIP</span>
                        </div>
                        <div class="user-avatar">
                            <?php if (!empty($_SESSION['customer_avatar'])): ?>
                                <img src="<?php echo $_SESSION['customer_avatar']; ?>" alt="头像" class="avatar-img">
                            <?php else: ?>
                                <div class="avatar-icon"><?php echo mb_substr($_SESSION['customer_name'], 0, 1); ?></div>
                            <?php endif; ?>
                            <span class="user-name"><?php echo $_SESSION['customer_name']; ?></span>
                            <?php if ($_SESSION['is_member']): ?>
                                <?php if ($_SESSION['member_level'] == '永久会员' || $_SESSION['member_expire_time'] == '2099-12-31'): ?>
                                    <span class="member-badge permanent-member">永久会员</span>
                                <?php else: ?>
                                    <span class="member-badge"><?php echo $_SESSION['member_level']; ?></span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <div class="user-dropdown">
                            <div class="dropdown-header">
                                <div class="dropdown-avatar">
                                    <?php if (!empty($_SESSION['customer_avatar'])): ?>
                                        <img src="<?php echo $_SESSION['customer_avatar']; ?>" alt="头像" class="dropdown-avatar-img">
                                    <?php else: ?>
                                        <div class="dropdown-avatar-icon"><?php echo mb_substr($_SESSION['customer_name'], 0, 1); ?></div>
                                    <?php endif; ?>
                                </div>
                                <div class="dropdown-user-info">
                                    <div class="dropdown-username"><?php echo $_SESSION['customer_name']; ?></div>
                                    <div class="dropdown-member-status">
                                        <?php if ($_SESSION['is_member']): ?>
                                            <?php if ($_SESSION['member_level'] == '永久会员' || $_SESSION['member_expire_time'] == '2099-12-31'): ?>
                                                <span class="permanent-badge">永久会员</span>
                                            <?php else: ?>
                                                <span class="member-badge"><?php echo $_SESSION['member_level']; ?></span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="non-member">非会员</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="divider"></div>
                            <a href="customer_center.php" class="dropdown-item">个人中心</a>
                            <a href="customer_logout.php" class="dropdown-item">退出登录</a>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- 未登录时显示 -->
                    <div class="login-buttons">
                        <a href="login.php" class="login-btn">登录</a>
                        <a href="register.php" class="login-btn customer">注册</a>
                    </div>
                <?php endif; ?>
            </nav>
        </div>
    </header>
    <!-- 轮播图 -->
    <div class="carousel">
        <div class="carousel-slide active">
            <img src="https://picsum.photos/id/1062/1200/420" alt="理发店环境">
            <div class="carousel-caption">
                <h2>专业团队，用心服务</h2>
                <p>打造属于你的专属造型</p>
            </div>
        </div>
        <div class="carousel-slide">
            <img src="https://picsum.photos/id/1076/1200/420" alt="服务项目">
            <div class="carousel-caption">
                <h2>多样套餐，满足你的需求</h2>
                <p>精剪造型、烫染护理、头皮养护</p>
            </div>
        </div>
        <div class="carousel-slide">
            <img src="https://picsum.photos/id/1083/1200/420" alt="客户评价">
            <div class="carousel-caption">
                <h2>客户满意是我们的追求</h2>
                <p>上千客户的选择，值得信赖</p>
            </div>
        </div>
        <button class="carousel-prev" onclick="prevSlide()">&#10094;</button>
        <button class="carousel-next" onclick="nextSlide()">&#10095;</button>
    </div>
    <!-- 统计卡片 -->
    <div class="stats-container">
        <div class="stat-card total-members">
            <div class="stat-title">总会员数</div>
            <div class="stat-value"><?php echo $total_members; ?></div>
            <div class="stat-subtitle">所有注册客户</div>
        </div>
        <div class="stat-card today-bookings">
            <div class="stat-title">今日预约</div>
            <div class="stat-value"><?php echo $today_bookings; ?></div>
            <div class="stat-subtitle">今日预约数量</div>
        </div>
        <div class="stat-card today-spend">
            <div class="stat-title">今日消费</div>
            <div class="stat-value"><?php echo number_format($today_spend, 2); ?> 元</div>
            <div class="stat-subtitle">今日总消费金额</div>
        </div>
        <div class="stat-card total-services">
            <div class="stat-title">服务项目</div>
            <div class="stat-value"><?php echo $total_services; ?></div>
            <div class="stat-subtitle">提供的服务数量</div>
        </div>
    </div>
    <!-- 店铺信息 -->
    <div class="shop-info" id="about">
        <h2>关于我们</h2>
        <p>我们是一家专业的理发店，拥有经验丰富的造型师团队，为您提供优质的美发服务。我们致力于为每一位客户打造专属的时尚造型，让您展现最美的自己。</p>
        <div class="info-grid">
            <div class="info-item">
                <div class="info-icon">📍</div>
                <h3>店铺地址</h3>
                <p>河北省石家庄市新乐市XX路XX号</p>
            </div>
            <div class="info-item">
                <div class="info-icon">📞</div>
                <h3>联系电话</h3>
                <p>138XXXXXXX</p>
            </div>
            <div class="info-item">
                <div class="info-icon">⏰</div>
                <h3>营业时间</h3>
                <p>周一至周日 09:00-21:00</p>
            </div>
            <div class="info-item">
                <div class="info-icon">⭐</div>
                <h3>特色服务</h3>
                <p>一对一专属造型师、免费设计、会员折扣</p>
            </div>
        </div>
    </div>
    <!-- 服务项目 -->
    <div class="services" id="services">
        <h2>我们的服务</h2>
        <div class="service-grid">
            <?php
            // 获取所有可用套餐
            $packages_result = mysqli_query($conn, "SELECT * FROM packages WHERE is_enable = 1 ORDER BY default_price ASC");
            if (!$packages_result) {
                $packages = [];
                error_log('查询套餐列表失败: ' . mysqli_error($conn));
            } else {
                $packages = mysqli_fetch_all($packages_result, MYSQLI_ASSOC);
            }
            if (empty($packages)):
            ?>
                <div class="no-data">暂无可用服务套餐</div>
            <?php else: ?>
                <?php foreach ($packages as $package): ?>
                    <div class="service-card">
                        <?php if (!empty($package['image_url'])): ?>
                            <img src="<?php echo $package['image_url']; ?>" alt="<?php echo $package['package_name']; ?>" class="service-image">
                        <?php else: ?>
                            <img src="https://picsum.photos/id/1062/300/200" alt="<?php echo $package['package_name']; ?>" class="service-image">
                        <?php endif; ?>
                        <h3><?php echo $package['package_name']; ?></h3>
                        <p><?php echo $package['package_description'] ?? '专业发型师服务，为您打造专属造型'; ?></p>
                        <div class="service-price">参考价格：¥<?php echo number_format($package['default_price'], 2); ?></div>
                        <a href="<?php echo isset($_SESSION['customer_logged_in']) && $_SESSION['customer_logged_in'] ? 'customer_center.php#book-tab' : 'login.php#customer-tab'; ?>" class="book-btn">立即预约</a>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    <!-- 客户评价 -->
    <div class="reviews" id="reviews">
        <h2>客户评价</h2>
        <div class="review-grid">
            <div class="review-card">
                <div class="reviewer-info">
                    <div class="avatar">张</div>
                    <div class="reviewer-name">张先生</div>
                    <div class="rating">⭐⭐⭐⭐⭐</div>
                </div>
                <p class="review-content">服务非常好，造型师很专业，剪出来的发型很满意，下次还会再来！</p>
            </div>
            <div class="review-card">
                <div class="reviewer-info">
                    <div class="avatar">李</div>
                    <div class="reviewer-name">李女士</div>
                    <div class="rating">⭐⭐⭐⭐⭐</div>
                </div>
                <p class="review-content">烫染效果很好，颜色很喜欢，头皮也没有不舒服的感觉，推荐给大家！</p>
            </div>
            <div class="review-card">
                <div class="reviewer-info">
                    <div class="avatar">王</div>
                    <div class="reviewer-name">王先生</div>
                    <div class="rating">⭐⭐⭐⭐⭐</div>
                </div>
                <p class="review-content">环境很好，服务很贴心，等待的时候还有免费的饮品，体验非常棒！</p>
            </div>
        </div>
    </div>
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-logo">
                    <div class="logo-icon">理</div>
                    <div>专业理发店</div>
                </div>
                <div class="footer-links">
                    <a href="index.php">首页</a>
                    <a href="#services">服务项目</a>
                    <a href="#about">关于我们</a>
                    <a href="#reviews">客户评价</a>
                </div>
                <div class="footer-contact">
                    <p>地址：河北省石家庄市新乐市XX路XX号</p>
                    <p>电话：138XXXXXXX</p>
                    <p>营业时间：周一至周日 09:00-21:00</p>
                </div>
            </div>
            <div class="copyright">
                &copy; 2026 专业理发店 版权所有
            </div>
        </div>
    </footer>
    <script>
        // 轮播图功能
        let currentSlide = 0;
        const slides = document.querySelectorAll('.carousel-slide');
        function showSlide(index) {
            slides.forEach(slide => slide.classList.remove('active'));
            slides[index].classList.add('active');
        }
        function nextSlide() {
            currentSlide = (currentSlide + 1) % slides.length;
            showSlide(currentSlide);
        }
        function prevSlide() {
            currentSlide = (currentSlide - 1 + slides.length) % slides.length;
            showSlide(currentSlide);
        }
        // 自动轮播
        setInterval(nextSlide, 5000);
        // 平滑滚动
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
    </script>
</body>
</html>
