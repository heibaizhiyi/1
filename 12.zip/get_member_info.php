<?php
session_start();
if (!isset($_SESSION['customer_logged_in']) || $_SESSION['customer_logged_in'] !== true) {
    exit;
}
include 'db_config.php';
$customer_id = $_SESSION['customer_id'];
// 查询会员信息
$member_stmt = mysqli_prepare($conn, "SELECT * FROM members WHERE id = ?");
mysqli_stmt_bind_param($member_stmt, 'i', $customer_id);
mysqli_stmt_execute($member_stmt);
$member = mysqli_fetch_assoc(mysqli_stmt_get_result($member_stmt));
// 返回JSON
echo json_encode($member);
?>