<?php
session_start();
if (!isset($_SESSION['customer_logged_in']) || $_SESSION['customer_logged_in'] !== true) {
    header('Location: login.php#customer-tab');
    exit;
}
include 'db_config.php';
// 检查是否已经是会员
$check_member_sql = 'SELECT is_member FROM members WHERE id = ?';
$stmt = mysqli_prepare($conn, $check_member_sql);
mysqli_stmt_bind_param($stmt, 'i', $_SESSION['customer_id']);
mysqli_stmt_execute($stmt);
$member = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
if ($member['is_member'] == 1) {
    header('Location: customer_center.php?msg=您已经是会员，无需重复申请&type=error');
    exit;
}
// 检查是否已经提交过申请
$check_app_sql = 'SELECT id FROM member_applications WHERE customer_id = ? AND status = \'pending\'';
$stmt = mysqli_prepare($conn, $check_app_sql);
mysqli_stmt_bind_param($stmt, 'i', $_SESSION['customer_id']);
mysqli_stmt_execute($stmt);
$app = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
if ($app) {
    header('Location: customer_center.php?msg=您已经提交过会员申请，请等待店长审核&type=error');
    exit;
}
// 插入会员申请
$insert_sql = 'INSERT INTO member_applications (customer_id) VALUES (?)';
$stmt = mysqli_prepare($conn, $insert_sql);
mysqli_stmt_bind_param($stmt, 'i', $_SESSION['customer_id']);
if (mysqli_stmt_execute($stmt)) {
    // 发送消息给店长
    $admin_id = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM admin LIMIT 1"))['id'];
    $message_content = "有新的会员申请，请及时审核";
    $send_msg_sql = "INSERT INTO chat_messages (sender_id, receiver_id, message, send_time, is_read, sender_type) VALUES (?, ?, ?, NOW(), 0, 'customer')";
    $stmt = mysqli_prepare($conn, $send_msg_sql);
    mysqli_stmt_bind_param($stmt, 'iis', $_SESSION['customer_id'], $admin_id, $message_content);
    mysqli_stmt_execute($stmt);
    
    header('Location: customer_center.php?msg=会员申请提交成功，请等待店长审核&type=success');
} else {
    header('Location: customer_center.php?msg=会员申请提交失败：' . mysqli_error($conn) . '&type=error');
}
exit;
?>
