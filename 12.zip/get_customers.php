<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    exit;
}
include 'db_config.php';
$admin_id = $_SESSION['admin_id'];
// 查询所有客户（包含未读消息数量）
$chat_sessions_stmt = mysqli_prepare($conn, "SELECT m.id, m.name, m.phone, m.avatar, (SELECT COUNT(*) FROM chat_messages WHERE receiver_id = ? AND sender_id = m.id AND is_read = 0) as unread_count FROM members m ORDER BY m.name");
mysqli_stmt_bind_param($chat_sessions_stmt, 'i', $admin_id);
mysqli_stmt_execute($chat_sessions_stmt);
$chat_sessions_result = mysqli_stmt_get_result($chat_sessions_stmt);
$chat_sessions = mysqli_fetch_all($chat_sessions_result, MYSQLI_ASSOC);
?>
<?php foreach ($chat_sessions as $session): ?>
    <div class="chat-item" data-customer-id="<?php echo $session['id']; ?>" onclick="switchChat(<?php echo $session['id']; ?>)">
        <div class="customer-avatar">
            <?php if (!empty($session['avatar'])): ?>
                <img src="<?php echo $session['avatar']; ?>" alt="客户头像" class="avatar-img">
            <?php else: ?>
                <div class="avatar-icon"><?php echo mb_substr($session['name'], 0, 1); ?></div>
            <?php endif; ?>
        </div>
        <div class="customer-info">
            <div class="customer-name"><?php echo $session['name']; ?></div>
            <div class="customer-phone"><?php echo $session['phone']; ?></div>
        </div>
        <?php if ($session['unread_count'] > 0): ?>
            <div class="unread-badge"><?php echo $session['unread_count']; ?></div>
        <?php endif; ?>
    </div>
<?php endforeach; ?>